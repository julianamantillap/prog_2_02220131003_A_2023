/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio1;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner;
public class Ejercicio1 {

   
    public static void main(String[] args) {
        Scanner entrada= new Scanner (System.in);
        System.out.println("hola, como estas? me puedes decir tu nombre porfavor");
        String respuesta=entrada.nextLine();
        System.out.println("hola, bienvenido!!");
    }
    
}
