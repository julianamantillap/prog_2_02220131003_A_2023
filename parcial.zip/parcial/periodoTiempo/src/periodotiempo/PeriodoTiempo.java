/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package periodotiempo;
import java.util.Scanner;

public class PeriodoTiempo {

    
    public static void main(String[] args) {
         Scanner scanner =  new Scanner (System.in);
         int segundos;
         int dias;
         int horas;
         int minutos;
         int numero;
         
         System.out.println("con este programa se puede determinar un numero expresado en segundos, los imprime en minutos, horas y dias");
         System.out.print("ingrese el numero entero: ");
         numero = scanner.nextInt();
         
         dias = numero / 86400;
         horas = (numero % 86400) / 3600;
         minutos = ((numero % 86400) % 3600) / 60;
         segundos = ((numero % 86400) % 3600) % 60;
         
         System.out.println(" el equivalente en dias es: " + dias + " el equivalente en horas es: " + horas + " el equivalente en minutos es: " + minutos + " y el equivalente en segundos es: " + segundos);
         
    }
    
}
