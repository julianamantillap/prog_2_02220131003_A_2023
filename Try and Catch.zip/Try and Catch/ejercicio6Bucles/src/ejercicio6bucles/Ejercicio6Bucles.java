/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio6bucles;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio6Bucles {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double base;
        int exponente;
        double resultado;

        System.out.println("El programa solicitará un número real como base y un exponente entero positivo para calcular una potencia");
        
        try {
            System.out.print("Introduce la base de la potencia: ");
            base = scanner.nextDouble();
            
            do {
                System.out.print("Introduce el exponente entero de la potencia: ");
                exponente = scanner.nextInt();
                if (exponente <= 0) {
                    System.out.print("Error, el exponente debe ser un entero positivo");
                }
            } while (exponente <= 0);
            
            resultado = base;
            
            for (int i = 1; i < exponente; i++) {
                resultado *= base;
            }
            
            System.out.println("El resultado de la potencia es: " + resultado);
        } catch (InputMismatchException ex) {
            System.out.println("no se pueden agregar letras, solo numeros");
        }
    }
}

