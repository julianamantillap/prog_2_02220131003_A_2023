/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio07;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio07 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        int x1;
        int x2;
        int y1;
        int y2;
        int r1;
        int r2;
        double distancia;
        
        System.out.println("en este programa se calcula como son dos circunsferencias entre si, conociendo sus centros y radios");
        System.out.print("introduce el valor \"x\" de la primera circunferencia: ");
        x1 = scanner.nextInt();
        System.out.print("introduce el valor \"y\" de la primera circunferencia: ");
        y1 = scanner.nextInt();
        System.out.print("introduce el radio de la primera circunferencia: ");
        r1 = scanner.nextInt();
        System.out.print("introduce el valor \"x\" de la segunda circunferencia: ");
        x2 = scanner.nextInt();
        System.out.print("introduce el valor \"y\" de la segunda circunferencia: ");
        y2 = scanner.nextInt();
        System.out.print("introduce el radio de la segunda circunferencia: ");
        r2 = scanner.nextInt();
        
        distancia = Math.sqrt(Math.pow((x2-x1),2)+Math.pow((y2-y1),2));
        
        if (distancia == 0) {
            System.out.println("concentricas");
        }else if (distancia > (r1+r2)) {
            System.out.println("exteriores");
        }else if ((distancia > 0) && distancia < Math.abs (r1-r2)) {
            System.out.println("interiores");
        }else if (distancia == (r1+r2)) {
            System.out.println("tangentes exteriores");
        }else if (distancia == Math.abs (r1-r1))
        {
            System.out.print ("tangentes interiores");
        }else if (distancia < (r1-r2) && distancia > Math.abs (r1-r2)) {
           System.out.println("secantes"); 
        }
                
    }
    
}
