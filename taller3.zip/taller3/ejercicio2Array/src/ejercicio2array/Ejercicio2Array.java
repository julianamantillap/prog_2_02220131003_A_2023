/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio2array;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio2Array {

    
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
       
        int[] numero = new int[10];

      System.out.println("Programa que pide 10 numeros y calcula el maximo y minimo.");
        
     for (int i=0;i<10;i++) {     
            System.out.print("Introduce el numero "+(i+1)+": ");
            numero[i] = scanner.nextInt();   
     }
     
        int maximo=numero[0];
        int minimo=numero[0];
     
     for(int i=0; i<10; i++){
         
            if (numero[i]<minimo) {
                minimo  = numero[i];
                }
            if (numero[i]>maximo) {
                maximo = numero[i];
            }
     }
 
        for (int i=0; i<10;i++) {
            if (numero[i]==maximo) {
                System.out.println("Numero "+ (i+1)+": "+numero[i] + " maximo.");
                }
            else if (numero[i]== minimo) {
                System.out.println("Numero "+ (i+1)+": "+numero[i] + " minimo.");
            }
            else {
                System.out.println("Numero "+ (i+1)+": "+numero[i]);
            }
        }
    }
}  
    
    

