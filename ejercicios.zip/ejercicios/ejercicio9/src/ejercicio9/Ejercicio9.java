/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio9;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner;
public class Ejercicio9 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        double PrecioCompra;
        double PrecioDescuento;
        
        System.out.println("Con este programa se puede calcular el descuento del 15% de una venta");
        System.out.println("indica el precio de la venta sin el descuento: ");
        PrecioCompra = scanner.nextDouble();
        
        PrecioDescuento = PrecioCompra - (PrecioCompra * 0.15);
        
        System.out.println("el precio total del producto con su descuento es: "+PrecioDescuento);
    }
    
}
