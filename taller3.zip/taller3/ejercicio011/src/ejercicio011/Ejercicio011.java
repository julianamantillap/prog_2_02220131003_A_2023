/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio011;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio011 {

   
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        int numeroAlumnos;
        
        System.out.println(" en este programa se calcula el precio a pagar por alumno en el viaje de fin de curso, segun la cantidad que se apunte: ");
        System.out.print("numero de alumnos: ");
        numeroAlumnos = scanner.nextInt();
        
        if (numeroAlumnos >= 100) {
            System.out.println("el pago de la agencia es de " + numeroAlumnos*65 + "" + "euros y cada uno debe pagar 65 euros");
        } else if (numeroAlumnos <100 && numeroAlumnos >= 50) {
            System.out.println("el pago a la agencia es de " + numeroAlumnos*70 + "" + "euros y cada uno debe pagar 70 euros");
        }else if (numeroAlumnos < 50 && numeroAlumnos >= 30) {
            System.out.println("el pago a la agencia es de " + numeroAlumnos*95 + "" + "euros y cada uno debe pagar 95 euros");
        }else {
            System.out.println("el coste del autobus es de 4000 euros y cada alumno debe pagar " + (4000 / numeroAlumnos) + " euros");
        }
    }
    
}
