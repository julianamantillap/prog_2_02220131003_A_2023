/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author julianamantilla
 */
public class FiguraGeometrica {
    
    private int numerolados;
    private int[] lados;

    public FiguraGeometrica() {
    }

    public FiguraGeometrica(int numerolados, int[] lados) {
        this.numerolados = numerolados;
        this.lados = lados;
    }

    public int getNumerolados() {
        return numerolados;
    }

    public void setNumerolados(int numerolados) {
        this.numerolados = numerolados;
    }

    public int[] getLados() {
        return lados;
    }

    public void setLados(int[] lados) {
        this.lados = lados;
    }

    @Override
    public String toString() {
        return "FiguraGeometrica{" + "numerolados=" + numerolados + ", lados=" + lados + '}';
    }
    
    public double calcularArea(){
        
        double area = 1; 
        for(int i=0;i<this.lados.length;i++){
            area*= this.lados[i];
        }   
        return area;
    }

    public double calcularPerimetro(){
        
        double perimetro = 0;
        for(int i=0;i<this.lados.length;i++){
            perimetro += this.lados[i];
            
        }
 
         return perimetro;
         
    }
}
          
            
        

          
    
    

    
   
    
    
    

