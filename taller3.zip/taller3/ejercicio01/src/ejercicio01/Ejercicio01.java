/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio01;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */

public class Ejercicio01 {

  
    public static void main(String[] args) {
    Scanner scanner = new Scanner (System.in);
    int primerNumero;
    int segundoNumero;
    
System.out.println("Este programa pide dos números y calcula cual es mayor.");
    System.out.print("Introduce el primer número: ");
    primerNumero = scanner.nextInt();
    System.out.print("Introduce el segundo número: ");
    segundoNumero = scanner.nextInt();
    
if (primerNumero > segundoNumero){
        System.out.println("El primer número, " +primerNumero + ", es mayor que el número dos," +segundoNumero);
    }else if (primerNumero < segundoNumero){
        System.out.println("El segundo número, " +segundoNumero + ", es mayor que el primer número " +primerNumero);
    }else {
        System.out.println("Ambos números son iguales, " +primerNumero);
    }    
  }
}
        
