/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio8bucles;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio8Bucles {

    
    public static void main(String[] args) {
      int hora;
    int minuto;
    int segundo;
    String borraAnterior = "\b\b\b\b\b\b\b\b"; 
    
    for (hora=0; hora<=23; hora++) {
    
       for (minuto=0; minuto<=59; minuto++) {

       for (segundo=0; segundo<=59; segundo++) {
           
          System.out.printf("%02d:%02d:%02d",hora,minuto,segundo);
          TimeUnit.SECONDS.sleep(1);
          System.out.print(borraAnterior);
        }
      }
    }
  }
} 
           
    
    

