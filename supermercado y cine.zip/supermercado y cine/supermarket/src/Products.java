/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author julianamantilla
 */
public class Products {
    
    private String name;
    private String category;
    private double price;
    private String barcode;
    private int productsAmount;
    private String expirationDate;

    public Products(String name, String category, double price, String barcode, int productsAmount, String expirationDate) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.barcode = barcode;
        this.productsAmount = productsAmount;
        this.expirationDate = expirationDate;
    }
    
    public double costoPagar(){
        return this.productsAmount*this.price;
    }

    public Products() {
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public int getProductsAmount() {
        return productsAmount;
    }

    public void setProductsAmount(int productsAmount) {
        this.productsAmount = productsAmount;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    @Override
    public String toString() {
        return "Products{" + "name=" + name + ", category=" + category + ", price=" + price + ", barcode=" + barcode + ", productsAmount=" + productsAmount + ", expirationDate=" + expirationDate + '}';
    }
    
    
    
}