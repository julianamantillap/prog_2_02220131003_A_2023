/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio4bucles;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */


public class Ejercicio4Bucles {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numero1;
        int numero2;
        int minimo;
        int maximo;

        System.out.println("El programa imprimirá todos los números pares entre dos números indicados.");

        try {
            System.out.println("Introduzca el primer número: ");
            numero1 = scanner.nextInt();
            System.out.println("Introduzca el segundo número: ");
            numero2 = scanner.nextInt();

            if (numero1 < numero2) {
                minimo = numero1;
                maximo = numero2;
            } else {
                minimo = numero2;
                maximo = numero1;
            }

            for (int i = minimo + 1; i < maximo; i++) {
                if (i % 2 == 0) {
                    System.out.println(i);
                }
            }
        } catch (InputMismatchException ex) {
            System.out.println("no se pueden agregar letras, solo numeros");
        }
    }
}

