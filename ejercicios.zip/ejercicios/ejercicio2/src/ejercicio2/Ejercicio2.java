/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio2;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner; 
public class Ejercicio2 {

    private static Scanner Sc; 
    
    public static void main(String[] args) {
        
        double perimetro, area;
        double base = leerNumeroReal("introduce la base del rectangulo: ");
        double altura = leerNumeroReal("introduce la altura del rectangulo: ");
        perimetro = 2* (base+altura);
        
        System.out.printf("%nEl perimetro del rectangulo de base %.2f y altura %.2f es %.2f.", base, altura, perimetro);
        System.out.printf("%nEl area del rectangulo de base %.2f y altura %.2f es %.2f.", base, altura, perimetro);
        
    }
    
    private static double leerNumeroReal(String s){
        Sc = new Scanner (System.in);
        System.out.print(s);
        return Sc.nextDouble();
        
    }
   
    
}
