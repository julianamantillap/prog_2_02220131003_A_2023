/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio8;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner;
public class Ejercicio8 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        double SalarioBase;
        double venta1;
        double venta2;
        double venta3;
        double comision;
        double SalarioTotal;
        
        System.out.println("Aqui se calcula el salario de un trabajador contando comisiones");
        System.out.println("indica aqui tu salario base: ");
        SalarioBase = scanner.nextDouble();
        System.out.println("Indique la ganancia de la primera venta");
        venta1 = scanner.nextDouble();
        System.out.println("Indique la ganancia de la segunda venta");
        venta2 = scanner.nextDouble();
        System.out.println("Indique la ganancia de la tercera venta");
        venta3 = scanner.nextDouble();
        
        comision = 0.1*(venta1 + venta2 + venta3);
        
        SalarioTotal = SalarioBase + comision;
        
        System.out.println("el sueldo total a recibir es "+SalarioTotal +"\nEquilavente al salario base: "+SalarioBase + " y comisiones: "+comision);
    }
    
}
