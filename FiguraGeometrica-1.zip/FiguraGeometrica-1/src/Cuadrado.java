/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author julianamantilla
 */
public class Cuadrado extends FiguraGeometrica {
    
    private String nombre;

    public Cuadrado(String nombre, int numerolados, int[] lados) {
        super(numerolados, lados);
        this.nombre = nombre;
    }

    public Cuadrado() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Cuadrado{" + "nombre=" + nombre + '}';
    }
    
    @Override
    public double calcularArea(){
        
        int area = 0;
        for(int i=0; i<super.getLados().length;i++){
            area+= super.getLados()[i];
        }   
        //area = 4 * super.getLados()[0];
        
        
        return area;
    }
    
   
    
     
  }
