/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cinema;

/**
 *
 * @author julimantilla
 */
public class Ticket {
    
    private String id;
    private Client client;
    private Food[] food;
    private Hall hall;
    private Movie[] movie;
    private Worker worker;
    private cashRegister cr;
    private double amount;

    public Ticket(String id, Client client, Food[] food, Hall hall, Movie[] movie, Worker worker, cashRegister cr, double amount) {
        this.id = id;
        this.client = client;
        this.food = food;
        this.hall = hall;
        this.movie = movie;
        this.worker = worker;
        this.cr = cr;
        this.amount = amount;
    }

    

    public Ticket() {
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
    

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Food[] getFood() {
        return food;
    }

    public void setFood(Food[] food) {
        this.food = food;
    }

    public Movie[] getMovie() {
        return movie;
    }

    public void setMovie(Movie[] movie) {
        this.movie = movie;
    }

    

    public Hall getHall() {
        return hall;
    }

    public void setHall(Hall hall) {
        this.hall = hall;
    }

   

    public Worker getWorker() {
        return worker;
    }

    public void setWorker(Worker worker) {
        this.worker = worker;
    }

    public cashRegister getCr() {
        return cr;
    }

    public void setCr(cashRegister cr) {
        this.cr = cr;
    }

    @Override
    public String toString() {
        
        String listadecomida = "";
        
        for(int i=0;i<this.food.length;i++)
            listadecomida+=this.food[i].getFoodType()+", ";
        
        String listapeliculas = "";
        
        for(int i=0;i<this.movie.length;i++)
            listapeliculas+=this.movie[i].getSynopsis()+", ";
        
        
        return "Ticket{" + "id=" + id + ", client=" + client.getName() + ", food=" + listadecomida + ", hall=" + hall.getHallNumber() + ", movie=" + listapeliculas + ", worker=" + worker.getName() + ", cr=" + cr.getCashRegisterNumber() + ", amount=" + amount + '}';
    }
    
}
