/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package udes.trianguloasteriscos;
import java.util.Scanner;

/**
 *
 * @author juli.mantilla
 */
public class TrianguloAsteriscos {


    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese la base del triángulo: ");
        int base = sc.nextInt();

        System.out.print("Ingrese la altura del triángulo: ");
        int altura = sc.nextInt();

        System.out.print("Ingrese la alineación del triángulo (l = izquierda, r = derecha): ");
        char alineacion = sc.next().charAt(0);

        if (alineacion == 'l') {
            // Triángulo alineado a la izquierda
            for (int i = 1; i <= altura; i++) {
                for (int j = 1; j <= i; j++) {
                    System.out.print("*");
                }
                System.out.println();
            }
        } else if (alineacion == 'r') {
            // Triángulo alineado a la derecha
            for (int i = 1; i <= altura; i++) {
                for (int j = altura - i; j > 0; j--) {
                    System.out.print(" ");
                }
                for (int k = 1; k <= i; k++) {
                    System.out.print("*");
                }
                System.out.println();
            }
        } else {
            // Error si la alineación ingresada no es 'l' ni 'r'
            System.out.println("Error: la alineación ingresada es incorrecta.");
        }
    }
}
