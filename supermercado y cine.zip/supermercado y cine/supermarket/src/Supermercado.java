
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author julianamantilla
 */
public class Supermercado {
    
    public static void main(String[] args) {
        
        System.out.println("Bienvenido al Sistema de supermercado Los Mantilla");
        
        Scanner scanner = new Scanner(System.in);
        Bill[] bill = null;
        int facturasAgregadas = 0;
        Products[] pro = null;
        int productosAgregados = 0;
        Client[] clie = null;
        int clientesAgregados = 0;
        
        int menu;
        int subMenu;
        
        Infraestructure inf = new Infraestructure("Av. libertadores", 5, "Pasillo de aseo, lacteos, snacks, ropa, utiles escolares", "1 parqueadero", 120.0);
        Schedule sch = new Schedule ("lunes a viernes", "festivos");
        Worker wk1 = new Worker("Felipe", "Mantilla", "1090435511", "Cajero", "C1", 1000000.0, sch, "3112887317");
        Manager boss = new Manager ("Juliana", "Mantilla", sch, 2000000.0, "BS1");
        Cash_Register caja1 = new Cash_Register("1", wk1, "Rapida", "Efectivo");

        do{
        menu = mostrarMenu(scanner);
        switch (menu) {
            case 1:
                do{
                    subMenu = mostrarSubMenu(scanner);
                    switch (subMenu) {
                    case 1:
                        if(pro==null)
                            System.out.println("no hay productos agregados");
                        else
                            listarProducto(pro);
                        break;
                    case 2:
                     System.out.println("digite la cantidad de productos que va a agregar");
                        int cantProductos = scanner.nextInt();
                        pro = new Products[cantProductos];
                        while(cantProductos>0){
                            pro = agregarProduct(scanner, pro, productosAgregados);
                            cantProductos--;
                            productosAgregados++;
                        }
                        listarProducto(pro);
                        break;
                    case 3:
                         System.out.println("Regresando al Menu anterior"); 
                        break;
                    }
                }while(subMenu!=3);
                break;
            case 2:
                do{
                    subMenu = mostrarSubMenu(scanner);
                    switch (subMenu) {
                    case 1:
                        if(clie==null)
                            System.out.println("no hay clientes agregados");
                        else
                            listarClients(clie);
                        break;
                    case 2:
                     System.out.println("digite la cantidad de clientes que va a agregar");
                        int cantClientes = scanner.nextInt();
                        clie = new Client[cantClientes];
                        while(cantClientes>0){
                            clie = agregarClient(scanner, clie, clientesAgregados);
                            cantClientes--;
                            clientesAgregados++;
                        }
                        listarClients(clie);
                        break;
                    case 3:
                         System.out.println("Regresando al Menu anterior");
                        break;
                    }
                }while(subMenu!=3);
                break;
            case 3:
                 do{
                    subMenu = mostrarSubMenu(scanner);
                    switch (subMenu) {
                    case 1:
                        if(bill==null)
                            System.out.println("no hay datos agregados");
                        else
                            listarFactura(bill);
                        break;
                    case 2:
                     System.out.println("digite la cantidad de facturas que va a agregar");
                        int cantfacturas = scanner.nextInt();
                        bill = new Bill[cantfacturas];
                        while(cantfacturas>0){
                            bill = agregarBill(scanner, bill, facturasAgregadas, productosAgregados, clientesAgregados, pro, clie, wk1, caja1);
                            cantfacturas--;
                            facturasAgregadas++;
                        }
                        //listarFactura(bill);
                        break;
                    case 3:
                        System.out.println("Regresando al Menu anterior");
                        break;
                    }
                }while(subMenu!=3);
                break;
            case 4:
                System.out.println("Gracias por Visitarnos, vuelva pronto!");
                break;
        }
    }while(menu!=4);
}
        
        public static int mostrarMenu (Scanner scanner) {
            System.out.println("Seleccione un menu");
            System.out.println("1. Productos");
            System.out.println("2. Cliente");
            System.out.println("3. Factura");
            System.out.println("4. Salir");
            return scanner.nextInt();
        }
        
        
    
        public static int mostrarSubMenu(Scanner scanner) {  
            System.out.println("Seleccione un submenu");
            System.out.println("1. Listar");
            System.out.println("2. Crear");
            System.out.println("3. Salir");
            return scanner.nextInt();
        }
        
         public static void listarFactura(Bill[] bill) {
            
             if (bill.length == 0)
             System.out.println("No hay facturas agregadas");
            else
                System.out.println("Las facturas agregadas son: ");
            for(Bill x: bill)
              System.out.println(x.toString());
        }
         
        public static void listarProducto(Products[] p) {
            
            if (p.length == 0)
             System.out.println("No hay Productos agregados");
            else
                System.out.println("Los Productos agregados son: ");
            for(Products ps: p)
              System.out.println(ps.toString());
        }
        
        public static void listarClients(Client[] cs) {
            
            if (cs.length == 0)
             System.out.println("No hay Clientes agregados");
            else
                System.out.println("Los Clientes agregados son: ");
            for(Client c: cs)
              System.out.println(c.toString());
        }

        
        public static Bill[] agregarBill(Scanner scanner, Bill[] bill, int facturasAgregadas, int productosAgregados, int clientesAgregados, Products[] prods, Client[] clients, Worker w1, Cash_Register c1) {
           
            if (productosAgregados == 0){
                System.out.println("Debe agregar al menos un producto para crear una factura");
                return null;
            }
             
            if (clientesAgregados == 0){
                System.out.println("Debe agregar al menos un cliente para crear una factura");
                return null;
            }
            
            System.out.println("Digite la informacion de la factura #" + (facturasAgregadas+1));
            System.out.println("ingrese la fecha");
            String fecha = scanner.next();
            System.out.println("ingrese el metodo de pago: ");
            String metpago = scanner.next();
            System.out.println("ingrese el tipo de factura: ");
            String tipFactura = scanner.next();
            
            double totalfactura = calcularCostoFactura(prods);
            Bill b = new Bill(prods, totalfactura, fecha, metpago, clients[0], tipFactura, w1, c1);
            bill[facturasAgregadas] = b;
            
            return bill;
        }
        
        public static Client[] agregarClient(Scanner scanner, Client[] clients, int clientesAgregados) {
            
            System.out.println("Digite la informacion del Cliente #" + (clientesAgregados+1));
            System.out.println("Ingrese el nombre del Cliente: ");
            String nombre = scanner.next();
            System.out.println("Ingrese el apellido del Cliente: ");
            String apellido = scanner.next();
            System.out.println("Ingrese el Número de Teléfono: ");
            String telefono = scanner.next();
            System.out.println("Ingrese el ID: ");
            String id = scanner.next();
            System.out.println("Ingrese el tipo de cliente: ");
            String tipoC = scanner.next();   
            
            Client c = new Client(nombre, apellido, telefono, id, tipoC);
            clients[clientesAgregados] = c;
            
            return clients;
        }
        
        public static Products[] agregarProduct(Scanner scanner, Products[] pros, int productosAgregados) {
            
            System.out.println("Digite la informacion del Producto #" + (productosAgregados+1));
            System.out.println("Ingrese el nombre del Producto: ");
            String nombre = scanner.next();
            System.out.println("Ingrese la Categoria del Producto: ");
            String categoria = scanner.next();
            System.out.println("Ingrese el precio del Producto: ");
            double precio = scanner.nextDouble();
            System.out.println("Ingrese el Código de Barras: ");
            String codbarras = scanner.next();
            System.out.println("Ingrese la Cantidad que desea llevar de este producto:  ");
            int cantidad = scanner.nextInt();
            System.out.println("Ingrese la fecha de Caducidad del producto:  ");
            String fechaexp = scanner.next();

            Products p = new Products(nombre, categoria, precio, codbarras, cantidad, fechaexp);
            pros[productosAgregados]= p;
            
            return pros;
        }
        
        public static double calcularCostoFactura(Products[] prods){
            
            double costo = 0.0;
            for(Products p: prods)
                costo+=p.costoPagar();
            return costo;
        }   
}

    
