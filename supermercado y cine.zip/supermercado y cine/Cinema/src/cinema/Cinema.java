/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cinema;
import java.util.Scanner;

/**
 *
 * @author julianamantilla
 */
public class Cinema {
    
    private static Scanner sc = new Scanner(System.in);
    private static Food[] foods = null;
    private static Ticket[] tickets = null;
    private static Client cli = new Client() ;
    private static Hall hall = new Hall();
    private static Movie[] movie = null;
    private static Schedule sche = new Schedule();
    private static Worker w1 = new Worker();
    private static cashRegister c1 = new cashRegister();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        System.out.println("Bienvenido al Cine Los Mantilla");
        
        int menu;
        int submenu;
        int peliculasagregadas=0;
        int ticketsagregados=0;
        int comidaagregada=0;
        
        w1 = new Worker("Yull", "Ramirez", "1090435511", "Cajero", "Caja1", 1500000.00, "Lunes a Viernes", "3112887317");
        c1 = new cashRegister(1, w1, "Caja Rapida", "Efectivo");
        String[] seats = {"A1", "A2", "A3", "A4", "A5"};
        hall = new Hall("Cinema 4D", 1, 100, "Reclinables", seats);
        sche = new Schedule("12PM - 5PM", "6PM - 11PM", "10AM-11PM");
        
        do{
        menu = mostrarMenu();
        switch (menu) {
            case 1:
                do{
                    submenu = mostrarSubMenu();
                    switch (submenu) {
                    case 1:
                        if(movie==null)
                            System.out.println("no hay peliculas agregados");
                        else
                            listMovies();
                        break;
                    case 2:
                     System.out.println("digite la cantidad de pelicuas que va a agregar");
                        int cantPeliculas = sc.nextInt();
                        movie = new Movie[cantPeliculas];
                        while(cantPeliculas>0){
                            addMovie(peliculasagregadas);
                            cantPeliculas--;
                            peliculasagregadas++;
                        }
                        listMovies();
                        break;
                    case 3:
                         System.out.println("Regresando al Menu anterior"); 
                        break;
                    }
                }while(submenu!=3);
                break;
            case 2:
                do{
                    submenu = mostrarSubMenu();
                    switch (submenu) {
                    case 1:
                        if(foods==null)
                            System.out.println("no hay comida agregada");
                        else
                            listFood();
                        break;
                    case 2:
                     System.out.println("digite la cantidad de comida que va a agregar");
                        int cantComida = sc.nextInt();
                        foods = new Food[cantComida];
                        while(cantComida>0){
                            addFood(comidaagregada);
                            cantComida--;
                            comidaagregada++;
                        }
                            listFood();
                        break;
                    case 3:
                         System.out.println("Regresando al Menu anterior");
                        break;
                    }
                }while(submenu!=3);
                break;
            case 3:
                 do{
                    submenu = mostrarSubMenu();
                    switch (submenu) {
                    case 1:
                        if(cli==null)
                            System.out.println("no hay Cliente agregado");
                        else
                            cli.toString();
                        break;
                    case 2:
                        addClient();
                        break;
                    case 3:
                        System.out.println("Regresando al Menu anterior");
                        break;
                    }
                }while(submenu!=3);
                break;
             case 4:
                do{
                    submenu = mostrarSubMenu();
                    switch (submenu) {
                    case 1:
                        if(tickets==null)
                            System.out.println("no hay tickets agregad");
                        else
                            listTickets();
                        break;
                    case 2:
                     System.out.println("digite la cantidad de tickets que va a agregar");
                        int cantTickets = sc.nextInt();
                        tickets = new Ticket[cantTickets];
                        while(cantTickets>0){
                            addTicket(ticketsagregados, peliculasagregadas, comidaagregada);
                            cantTickets--;
                            ticketsagregados++;
                        }
                        break;
                    case 3:
                         System.out.println("Regresando al Menu anterior");
                        break;
                    }
                }while(submenu!=3);
                break;        
            case 5:
                System.out.println("Gracias por Visitarnos, vuelva pronto!");
                break;
        }
    }while(menu!=5);   
    }
    
    public static void listFood() {
            
             if (foods.length == 0)
             System.out.println("No hay comida agregada");
            else
                System.out.println("La comida agregada es: ");
            for(Food x: foods)
              System.out.println(x.toString());
    }
    
    public static void listTickets() {
            
             if (tickets.length == 0)
             System.out.println("No hay tickets agregados");
            else
                System.out.println("Los Tickets agregads son: ");
            for(Ticket x: tickets)
              System.out.println(x.toString());
    }
    
    public static void listMovies() {
            
             if (movie.length == 0)
             System.out.println("No hay peliculas agregadas");
            else
                System.out.println("Las peliculas agregadas son: ");
            for(Movie x: movie)
              System.out.println(x.toString());
    }
    
    public static void addClient() {
            
            System.out.println("Digite la informacion del Cliente");
            System.out.println("Ingrese el nombre del Cliente: ");
            String nombre = sc.next();
            System.out.println("Ingrese el apellido del Cliente: ");
            String apellido = sc.next();
            System.out.println("Ingrese el Número de Teléfono: ");
            String telefono = sc.next();
            System.out.println("Ingrese la edad del Cliente: ");
            int edad = sc.nextInt();
            
            cli = new Client(nombre, apellido, telefono, edad);
            System.out.println("Registro Exitoso");
            
        }
    
    public static void addMovie(int peliculasAgregadas) {
            
            System.out.println("Digite la informacion de la pelicula #" + (peliculasAgregadas+1));
            System.out.println("Ingrese el genero de la pelicula: ");
            String genero = sc.next();
            System.out.println("Ingrese la duracion de la pelicula: ");
            String tipobebida = sc.next();
            System.out.println("Ingrese el rango de edad de la pelicula: ");
            int ageRange = sc.nextInt();
            System.out.println("Ingrese la sinopsis de la pelicula: ");
            String sinopsis = sc.next();
            System.out.println("Ingrese el tipo de pelicula: ");
            String tipoPeli = sc.next();
      
            Movie m = new Movie(genero, tipobebida, sche, ageRange, sinopsis, tipoPeli, hall);
            movie[peliculasAgregadas] = m;
        }
    
    public static void addTicket(int ticketsagregados, int peliculasAgregadas, int comidaAgregada) {
        
            if (peliculasAgregadas == 0){
                System.out.println("Debe agregar al menos una pelicula para crear una entrada");
                return;
            }
             
            if (comidaAgregada == 0){
                System.out.println("Debe agregar al menos una comida para crear una entrada");
                return;
            }
        
            
            System.out.println("Digite la informacion de la entrada #" + (ticketsagregados+1));
            System.out.println("Ingrese el codigo del Ticket: ");
            String codigo = sc.next();
            System.out.println("Ingrese el costo de la entrada: ");
            double costo = sc.nextDouble();       
      
            Ticket t = new Ticket(codigo, cli, foods, hall, movie, w1, c1, costo);
            tickets[ticketsagregados] = t;
        }
    
    
    public static void addFood(int comidaagregada) {
            
            System.out.println("Digite la informacion de la comida #" + (comidaagregada+1));
            System.out.println("Ingrese el tipo de comida: ");
            String tipocomida = sc.next();
            System.out.println("Ingrese el tipo de bebida: ");
            String tipobebida = sc.next();
            System.out.println("Ingrese el valor del combo: ");
            double valorCombo = sc.nextDouble();
      
            Food f = new Food(tipocomida, tipobebida, valorCombo);
            foods[comidaagregada] = f;
        }


    
    public static int mostrarMenu () {
            System.out.println("Seleccione un menu");
            System.out.println("1. Pelicula");
            System.out.println("2. Comida");
            System.out.println("3. Cliente");
            System.out.println("4. Ticket");
            System.out.println("5. Salir");
            return sc.nextInt();
        }
        
        public static int mostrarSubMenu() {  
            System.out.println("Seleccione un submenu");
            System.out.println("1. Listar");
            System.out.println("2. Crear");
            System.out.println("3. Salir");
            return sc.nextInt();
        }
}
