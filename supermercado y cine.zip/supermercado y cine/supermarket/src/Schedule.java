/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author julianamantilla
 */
public class Schedule {
    
    private String MondaytoSunday;
    private String holidays;

    public Schedule(String MondaytoSunday, String holidays) {
        this.MondaytoSunday = MondaytoSunday;
        this.holidays = holidays;
    }

    public Schedule() {
    }

    public String getMondaytoSunday() {
        return MondaytoSunday;
    }

    public void setMondaytoSunday(String MondaytoSunday) {
        this.MondaytoSunday = MondaytoSunday;
    }

    public String getHolidays() {
        return holidays;
    }

    public void setHolidays(String holidays) {
        this.holidays = holidays;
    } 

    @Override
    public String toString() {
        return "Schedule{" + "MondaytoSunday=" + MondaytoSunday + ", holidays=" + holidays + '}';
    }
    
    
    
}

