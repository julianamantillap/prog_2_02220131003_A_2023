/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio09;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio09 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        int year;
        
        System.out.println("en este programa se calcula si un año es bisiesto");
        System.out.print("introduce el año: ");
        year = scanner.nextInt();
        
        if (year % 400 == 0) {
            System.out.println("es un año bisiesto");
        }else if (year % 100 == 0){
            System.out.println("no es un año bisiesto");
        }else if (year % 4 == 0) {
            System.out.println("es un año bisiesto");
        }else{
            System.out.println("no es un año bisiesto");
        }
    }
    
}
