/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio18;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner;
public class Ejercicio18 {

   
    public static void main(String[] args) {
      Scanner scanner = new Scanner (System.in);
    String nombre;
    String apellido1;
    String apellido2;
    String iniciales= "";
    
    System.out.println("Este programa pide nombre y apellidos y después devuelve las iniciales.");
    System.out.print("Nombre: ");
    nombre = scanner.next();
    System.out.print("Primer apellido: ");
    apellido1 = scanner.next();
    System.out.print("Segundo apellido: ");
    apellido2 = scanner.next();
    
     iniciales+=  nombre.charAt(0)+apellido1.charAt(0)+apellido2.charAt(0);
     
     System.out.println("Las iniciales son: " +iniciales);
    }
    
}
