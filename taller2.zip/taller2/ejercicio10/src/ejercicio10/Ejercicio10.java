/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio10;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner;
public class Ejercicio10 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        double parcial1;
        double parcial2;
        double parcial3;
        double parciales;
        double examen;
        double trabajo;
        double nota;
        
        System.out.println("este programa calcula la nota final de un alumno teniendo en cuenta que la nota se compone de un 55% del valor de los parciales, un 30% de la calificacion del examen final y otro 15% de la calificacion del trabajo final.");
        System.out.print("indica la nota del primer parcial: ");
        parcial1 = scanner.nextDouble();
        System.out.print("indica la nota del segundo parcial: ");
        parcial2 = scanner.nextDouble();
        System.out.print("indica la nota del tercer parcial: ");
        parcial3 = scanner.nextDouble();
        System.out.print("indica la nota del examen: ");
        examen = scanner.nextDouble();
        System.out.print("indica la nota del trabajo final: ");
        trabajo = scanner.nextDouble();
        
        parciales = (parcial1 + parcial2 + parcial3) /3;
        nota = parciales * 0.55 + examen * 0.3 + trabajo * 0.15;
        
        System.out.println("la nota final es de " +nota );
    }
    
}
