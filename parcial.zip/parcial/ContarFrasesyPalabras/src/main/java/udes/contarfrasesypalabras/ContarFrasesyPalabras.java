/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package udes.contarfrasesypalabras;
import java.util.Scanner;
/**
 *
 * @author juli.mantilla
 */
public class ContarFrasesyPalabras {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite la frase que contaremos sus palabras y sus caracteres");
        String frase = sc.nextLine();
        
        String [] palabras = frase.split(" ");
        int cantpalabras = palabras.length;
        
        System.out.println("Su Frase tiene: "+cantpalabras+" Palabras\n");
        
        for(int i=0; i<cantpalabras; i++){
          
          System.out.println("Palabra #"+(i+1)+": "+palabras[i]);
          System.out.println("Cantidad de Letras: "+palabras[i].length()+"\n");
        }  
    }
}
