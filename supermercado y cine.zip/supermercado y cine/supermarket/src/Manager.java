/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author julianamantilla
 */
public class Manager {
 
    private String name;
    private String lastName;
    private Schedule schedule;
    private double salary;
    private String code;

    public Manager(String name, String lastName, Schedule schedule, double salary, String code) {
        this.name = name;
        this.lastName = lastName;
        this.schedule = schedule;
        this.salary = salary;
        this.code = code;
    }

    public Manager() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Schedule getSchedule() {
        return schedule;
    }

    public void setSchedule(Schedule schedule) {
        this.schedule = schedule;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String toString() {
        return "Manager{" + "name=" + name + ", lastName=" + lastName + ", schedule=" + schedule + ", salary=" + salary + ", code=" + code + '}';
    }
    
    
}

