/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.empresa;

/**
 *
 * @author Juliana
 */
public class JefeZona extends Empleado{
    
    private String despacho;
    private Secretario sec;
    private Vendedor[] listavendedores;
    private Coche c1;

    public JefeZona() {
    }

    public JefeZona(String despacho, Secretario sec, Coche c1, String nombre, String apellidos, String direccion, String dni, String numcontacto, double salario) {
        super(nombre, apellidos, direccion, dni, numcontacto, salario);
        this.despacho = despacho;
        this.sec = sec;
        this.c1 = c1;
    }

    public String getDespacho() {
        return despacho;
    }

    public void setDespacho(String despacho) {
        this.despacho = despacho;
    }

    public Secretario getSec() {
        return sec;
    }

    //Metodo para cambiar Secretaria
    public void setSec(Secretario sec) {
        this.sec = sec;
    }

    public Vendedor[] getListavendedores() {
        return listavendedores;
    }

    public void setListavendedores(Vendedor[] listavendedores) {
        this.listavendedores = listavendedores;
    }

    public Coche getC1() {
        return c1;
    }
    
    //Metodo para cambiar coche
    public void setC1(Coche c1) {
        this.c1 = c1;
    }

    @Override
    public String toString() {
        return "JefeZona{" + super.toString() + "despacho=" + despacho + ", Secretario=" + sec.getNombre()+ " " + sec.getApellidos() + ", coche=" + c1.getMarca()+ " " + c1.getMatricula() + '}';
    }
    
    public void aumentarSalario(){
        double incremento = super.getSalario()*0.20;
        super.aumentarSalario(incremento);
    }
    
    public void darAltaVendedor(){
        
    }
    
    public void darBajaVendedor(){
        
    }
    
}
