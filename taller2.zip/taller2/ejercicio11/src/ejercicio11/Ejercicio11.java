/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio11;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner;
public class Ejercicio11 {

   
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        int numero1;
        int numero2;
        int distancia;
        
        System.out.println("En este programa se calcula la distancia entre dos numeros dados");
        System.out.println("Introduce el primer numero: ");
        numero1 = scanner.nextInt();
        System.out.println("Introduce el segundo numero: ");
        numero2 = scanner.nextInt();
        
        distancia = Math.abs (numero1 - numero2);
        
        System.out.println("la distancia entre ambos numeros es " +distancia);
        
    
        }

    }
    

