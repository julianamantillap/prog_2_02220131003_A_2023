/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author julianamantilla
 */
public class edicifio {
    
    int altura;
    int numeroPisos;
    String color;
    String material;
    int capacidad;

    public edicifio(int altura, int numeroPisos, String color, String material, int capacidad) {
        this.altura = altura;
        this.numeroPisos = numeroPisos;
        this.color = color;
        this.material = material;
        this.capacidad = capacidad;
    }

    public edicifio() {
    }

    public int getAltura() {
        return altura;
    }

    public int getNumeroPisos() {
        return numeroPisos;
    }

    public String getColor() {
        return color;
    }

    public String getMaterial() {
        return material;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public void setNumeroPisos(int numeroPisos) {
        this.numeroPisos = numeroPisos;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }
    
    
    
    
}
