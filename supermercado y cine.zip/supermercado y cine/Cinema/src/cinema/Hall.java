/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cinema;

/**
 *
 * @author julianamantilla
 */
public class Hall {
    
    private String hallType;
    private int hallNumber;
    private int capacity;
    private String seatType;
    private String[] seats;

    public Hall(String hallType, int hallNumber, int capacity, String seatType, String[] seats) {
        this.hallType = hallType;
        this.hallNumber = hallNumber;
        this.capacity = capacity;
        this.seatType = seatType;
        this.seats = seats;
    }

    public Hall() {
    }

    public String[] getSeats() {
        return seats;
    }

    public void setSeats(String[] seats) {
        this.seats = seats;
    }

    @Override
    public String toString() {
        
        String asientos="";
        for(int i=0;i<this.seats.length;i++)
            asientos+=this.seats[i]+", ";
        
        return "Hall{" + "hallType=" + hallType + ", hallNumber=" + hallNumber + ", capacity=" + capacity + ", seatType=" + seatType + ", seats=" + asientos + '}';
    }

    public String getHallType() {
        return hallType;
    }

    public void setHallType(String hallType) {
        this.hallType = hallType;
    }


    public int getHallNumber() {
        return hallNumber;
    }

    public void setHallNumber(int hallNumber) {
        this.hallNumber = hallNumber;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getSeatType() {
        return seatType;
    }

    public void setSeatType(String seatType) {
        this.seatType = seatType;
    }
    
    
    
    
}
