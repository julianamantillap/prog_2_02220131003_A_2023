/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio7bucles;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio7Bucles {

    
    public static void main(String[] args) {
       Scanner scanner = new Scanner (System.in);
       double cuota;
       int mensualidades;
       double totalPagado = 0;
       
       System.out.println("en este programa se calcula la cuota correspondiente al pago mensual y el total a pagar al final de la financiacion por la compra de un producto");
       System.out.println("introduce la primera cuota a pagar: ");
       cuota = scanner.nextDouble();
       System.out.println("introduce el numero de meses de financiacion");
       mensualidades = scanner.nextInt();
       
       for (int i=1; i <= mensualidades; i++) {
           System.out.println("cuota "+ i +": " + cuota);
           totalPagado = totalPagado + cuota;
           cuota = cuota*2;
                   
     }
      System.out.println("total pagado por el produto: " + (int)totalPagado);
    }
    
}
