/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;



/**
 *
 * @author julianamantilla
 */
public class moto {
    
    String modelo;
    int añodef;
    double costo;
    String color;
    String placa;

   public moto (String modelo, int añodef, double costo, String color, String placa) {
       this.modelo = modelo;
       this.añodef = añodef;
       this.costo = costo;
       this.color = color;
       this.placa = placa;
   }
    

    public String getModelo() {
        return modelo;
    }

    public int getAñodef() {
        return añodef;
    }

    public double getCosto() {
        return costo;
    }

    public String getColor() {
        return color;
    }

    public String getPlaca() {
        return placa;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setAñodef(int añodef) {
        this.añodef = añodef;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }
    
    
   
    
    
    
    
    
}
