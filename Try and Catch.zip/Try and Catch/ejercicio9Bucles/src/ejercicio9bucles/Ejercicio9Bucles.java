/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio9bucles;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */


public class Ejercicio9Bucles {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numPrimos;
        int contador;
        boolean esPrimo;
        int divisor;
        int num;

        System.out.println("En el programa se muestra una cantidad solicitada de números primos.");
        
        try {
            System.out.print("Indícanos la cantidad de primos que deseas conocer: ");
            numPrimos = scanner.nextInt();
            
            System.out.println("1: 2");
            contador = 1;
            num = 3;
            
            while (contador < numPrimos) {
                esPrimo = true;
                divisor = 3;
                
                while ((divisor <= Math.sqrt(num)) && esPrimo) {
                    if (num % divisor == 0) {
                        esPrimo = false;
                    }
                    divisor += 2;
                }
                
                if (esPrimo) {
                    contador += 1;
                    System.out.println(contador + ": " + num);
                }
                num += 2;
            }
        } catch (InputMismatchException ex) {
            System.out.println("no se pueden agregar letras, solo numeros");
        }
    }
}

    
    

