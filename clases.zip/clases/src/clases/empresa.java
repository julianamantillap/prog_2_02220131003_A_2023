/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author julianamantilla
 */
public class empresa {
    
    String nombre;
    String ocupacion;
    int trabajadores;
    int dueños;

    public empresa(String nombre, String ocupacion, int trabajadores, int dueños) {
        this.nombre = nombre;
        this.ocupacion = ocupacion;
        this.trabajadores = trabajadores;
        this.dueños = dueños;
    }

    public empresa() {
    }

    public String getNombre() {
        return nombre;
    }

    public String getOcupacion() {
        return ocupacion;
    }

    public int getTrabajadores() {
        return trabajadores;
    }

    public int getDueños() {
        return dueños;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setOcupacion(String ocupacion) {
        this.ocupacion = ocupacion;
    }

    public void setTrabajadores(int trabajadores) {
        this.trabajadores = trabajadores;
    }

    public void setDueños(int dueños) {
        this.dueños = dueños;
    }
    
    
}
