/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio06;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */


public class Ejercicio06 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int nota;
        int edad;
        String sexo;

        System.out.println("Este programa calcula la aceptación de una solicitud en base a los siguientes parámetros:");

        try {
            System.out.print("Edad: ");
            edad = scanner.nextInt();
            System.out.print("Nota: ");
            nota = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Sexo (M o F): ");
            sexo = scanner.nextLine();

            if (!sexo.equalsIgnoreCase("M") && !sexo.equalsIgnoreCase("F")) {
                System.out.println("El valor de sexo introducido es incorrecto. Por favor, vuelva a enviar el formulario.");
            } else if (nota >= 5 && edad >= 18 && sexo.equalsIgnoreCase("M")) {
                System.out.println("POSIBLE");
            } else if (nota >= 5 && edad >= 18 && sexo.equalsIgnoreCase("F")) {
                System.out.println("ACEPTADA");
            } else {
                System.out.println("NO ACEPTADA");
            }
         } catch (InputMismatchException ex) {
            System.out.println("no se pueden agregar letras, solo numeros");
        }
    }
}
