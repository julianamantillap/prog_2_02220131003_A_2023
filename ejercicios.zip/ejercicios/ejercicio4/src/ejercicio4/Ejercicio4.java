/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio4;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner;
public class Ejercicio4 {

   
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        double numero1;
        double numero2;
        
        System.out.println("Escribe dos numeros para obtener el resultado de su suma, resta, multiplicacion y division");
        System.out.print("dame el valor del primer numero: ");
        numero1 = scanner.nextDouble();
        
        System.out.print("dame el valor del segundo numero: ");
        numero2 = scanner.nextDouble(); 
        double suma= numero1 + numero2;
        
        System.out.println("la suma de estos numeros es: " + suma);
        System.out.println("la resta de estos numero es: " + (numero1 - numero2));
        System.out.println("la multiplicacion de estos numeros es: " + (numero1  * numero2));
        System.out.println("la division de estos numeros es: " + (numero1 / numero2));
        
    }
    
}
