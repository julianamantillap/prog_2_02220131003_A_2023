/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio03;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio03 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        int numerador;
        int denominador;
        
        System.out.println("este programa muestra la division entre dos numeros enteros");
        System.out.print("introduce el primer numero: ");
        numerador = scanner.nextInt();
        System.out.print("introduce el segundo numero: ");
        denominador = scanner.nextInt();
        
        if (denominador != 0){
            System.out.println((double)numerador/(double)denominador);
        }else{
            System.out.println("el segundo numero introducido es 0" + "reinicie el programa e introduzca un valor valido ");
            
        }
    }
    
}
