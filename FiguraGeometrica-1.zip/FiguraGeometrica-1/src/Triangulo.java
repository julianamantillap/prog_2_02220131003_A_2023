/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author YullR
 */
public class Triangulo extends FiguraGeometrica{
    
    private String tipo;

    public Triangulo() {
    }

    public Triangulo(String tipo, int numerolados, int[] lados) {
        super(numerolados, lados);
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Triangulo{" + "tipo=" + tipo + '}';
    }
    
    @Override
    public double calcularArea(){
       return (double)(super.getLados()[0]*super.getLados()[1])/2;    
    }

    
    
    
}
