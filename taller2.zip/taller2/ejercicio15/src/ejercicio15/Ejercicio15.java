/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio15;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner;
public class Ejercicio15 {

   
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        int valorA;
        int valorB;
        int valorC;
        
        System.out.println("este programa pide dos valores e intercambia el valor entre ambas variables");
        System.out.println("introduce el valor A: ");
        valorA = scanner.nextInt();
        System.out.println("introduce el valor B: ");
        valorB = scanner.nextInt();
        
        valorC = valorA;
        valorA = valorB;
        valorB = valorC;
        
        System.out.println("tras el cambio, valor A="+valorA + " y valor B="+valorB);
    }
    
}
