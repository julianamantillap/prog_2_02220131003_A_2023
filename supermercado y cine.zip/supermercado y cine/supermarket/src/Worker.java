/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author julianamantilla
 */
public class Worker {
    
    private String name;
    private String lastName;
    private String ID;
    private String workerType;
    private String code;
    private double salary;
    private Schedule schedule;
    private String phoneNumber;
    

    public Worker(String name, String lastName, String ID, String workerType, String code, double salary, Schedule schedule, String phoneNumber) {
        this.name = name;
        this.lastName = lastName;
        this.ID = ID;
        this.workerType = workerType;
        this.code = code;
        this.salary = salary;
        this.schedule = schedule;
        this.phoneNumber = phoneNumber;
    }

    public Worker() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getWorkerType() {
        return workerType;
    }

    public void setWorkerType(String workerType) {
        this.workerType = workerType;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public Schedule getSchedule() {
        return schedule;
    }

    public void setSchedule(Schedule schedule) {
        this.schedule = schedule;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public String toString() {
        return "Worker{" + "name=" + name + ", lastName=" + lastName + ", ID=" + ID + ", workerType=" + workerType + ", code=" + code + ", salary=" + salary + ", schedule=" + schedule + ", phoneNumber=" + phoneNumber + '}';
    }
    
    
}
