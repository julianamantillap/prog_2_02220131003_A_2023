/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author julianamantilla
 */
public class computador {
    
    String modelo;
    String marca;
    int tamaño;
    double almacenamiento;

    public computador(String modelo, String marca, int tamaño, double almacenamiento) {
        this.modelo = modelo;
        this.marca = marca;
        this.tamaño = tamaño;
        this.almacenamiento = almacenamiento;
    }

    public computador() {
    }

    public String getModelo() {
        return modelo;
    }

    public String getMarca() {
        return marca;
    }

    public int getTamaño() {
        return tamaño;
    }

    public double getAlmacenamiento() {
        return almacenamiento;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setTamaño(int tamaño) {
        this.tamaño = tamaño;
    }

    public void setAlmacenamiento(double almacenamiento) {
        this.almacenamiento = almacenamiento;
    }
    
    
    
    
}
