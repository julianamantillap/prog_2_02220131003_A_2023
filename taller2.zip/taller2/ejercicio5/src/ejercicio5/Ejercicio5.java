/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio5;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner;
public class Ejercicio5 {

   
    public static void main(String[] args) {
        Scanner scanner =  new Scanner (System.in);
        double fahrenheit;
        double celsius;
        
        System.out.println("Este programa pasa de grados Fahrenheit a Celsius");
        System.out.println("Dame la temperatura en grados Fahrenheit: ");
        fahrenheit = scanner.nextDouble();
        
        celsius = (fahrenheit - 32) / 1.8;
        
        System.out.println(fahrenheit +" grados fahrenheit son "+celsius + " grados celsius. ");
    }
    
}
