/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio010;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio010 {

   
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        int kilos; 
        double precioInicial;
        String tipo;
        int tamaño;
        
        System.out.println("con este programa se calcula la ganancia segun el tipo de vino, tamaño y cantidad vendida");
        System.out.print("introduce los Kg de uva entregada: ");
        kilos = scanner.nextInt();
        System.out.print("precio por Kg inicial: ");
        precioInicial = scanner.nextDouble();
        System.out.print("uva de valor \"A\" o \"B\": ");
        tipo = scanner.next();
        scanner.nextLine();
        System.out.print("tipo de uva \"1\" o \"2\": ");
        tamaño = scanner.nextInt();
        
        if (!((tipo.toUpperCase().equals("A") || tipo.toUpperCase().equals("B")) &&
        (tamaño == 1 || tamaño == 2))) {
      System.out.println("Tipo o tamaño incorrecto, vuelva a introducir los valores.");
    } else {
      if (tipo.toUpperCase().equals("A") && tamaño == 1) {
        System.out.println("La ganancia final es de: " + ((kilos * precioInicial)+(kilos*0.20)));
      } else if (tipo.toUpperCase().equals("A") && tamaño == 2) {
        System.out.println("La ganancia final es de: " + ((kilos*precioInicial)+(kilos*0.30)));
      } else if (tipo.toUpperCase().equals("B") && tamaño == 1) {
        System.out.println("La ganancia final es de: " + ((kilos * precioInicial)-(kilos*0.30)));
      } else if (tipo.toUpperCase().equals("B") && tamaño == 2) {
        System.out.println("La ganancia final es de: " + ((kilos*precioInicial)-(kilos*0.50)));
      }
    }
  }
}
    
    

