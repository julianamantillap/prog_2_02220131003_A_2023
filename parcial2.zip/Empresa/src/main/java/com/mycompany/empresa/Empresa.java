/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.empresa;

/**
 *
 * @author Juliana
 */
public class Empresa {

    public static void main(String[] args) {
        System.out.println("Bienvenido a la Empresa J");   
        
       
        
        Secretario sec = new Secretario("Despacho 1", "#Fax 6050", "Majo", "Soto", "Av Siempre viva", "1060", "312123121", 1500000);
        
        Coche c1 = new Coche("DDW-827", "2010", "Chevrolet");
        Coche c2 = new Coche("XXX-823", "2015", "Toyota");
        
       ;
        
        Vendedor v1 = new Vendedor(c1, "101010", "Ventas Nacionales", 0.07, "Joan", "Concha", "Alto de Santander", "1090435511", "3112887317", 1800000);
        
        JefeZona boss = new JefeZona("Despacho 1", sec, c2, "Juliana", "Mantilla", "Portachuelo", "606060", "312131", 2500000);
        
        sec.aumentarSalario();
        v1.aumentarSalario();
        boss.aumentarSalario();
        
        sec.setSupervisor(boss);
        v1.setSupervisor(boss);
        boss.setSupervisor(boss);  
        
        System.out.println(sec.toString());
        System.out.println(v1.toString());
        System.out.println(boss.toString());
        
    }
}
