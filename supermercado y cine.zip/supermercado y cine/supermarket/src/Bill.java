/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author julianamantilla
 */
public class Bill {
    
    private Products[] productsList;
    private double totalAmount;
    private String date;
    private String paymentMethod;
    private Client clientInformation;
    private String billType;
    private Worker workerInformation;
    private Cash_Register cashRegisterNumber;

    public Bill(Products[] productsList, double totalAmount, String date, String paymentMethod, Client clientInformation, String billType, Worker employerInformation, Cash_Register cashRegisterNumber) {
        this.productsList = productsList;
        this.totalAmount = totalAmount;
        this.date = date;
        this.paymentMethod = paymentMethod;
        this.clientInformation = clientInformation;
        this.billType = billType;
        this.workerInformation = employerInformation;
        this.cashRegisterNumber = cashRegisterNumber;
    }

    public Bill() {
    }

    public Products[] getProductsList() {
        return productsList;
    }

    public void setProductsList(Products[] productsList) {
        this.productsList = productsList;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Client getClientInformation() {
        return clientInformation;
    }

    public void setClientInformation(Client clientInformation) {
        this.clientInformation = clientInformation;
    }

    public String getBillType() {
        return billType;
    }

    public void setBillType(String billType) {
        this.billType = billType;
    }

    public Worker getWorkerInformation() {
        return workerInformation;
    }

    public void setWorkerInformation(Worker employerInformation) {
        this.workerInformation = employerInformation;
    }

    public Cash_Register getcashRegisterNumber() {
        return cashRegisterNumber;
    }

    public void setCashRegisterNumber(Cash_Register cashRegisterNumber) {
        this.cashRegisterNumber = cashRegisterNumber;
    }

    @Override
    
    public String toString() {
        
        String listadeproductos = "";
        
        for(int i=0;i<this.productsList.length;i++)
            listadeproductos+=this.productsList[i].getName()+", ";
        
        
        return "Factura:" + "Productos Comprados: " + listadeproductos + ", Total a Pagar: " + totalAmount + ", Fecha: " + date + ", paymentMethod=" + paymentMethod + ", clientInformation=" + clientInformation.getName()+" "+clientInformation.getLastName()+ ", billType=" + billType + ", workerInformation=" + workerInformation.getName() + ", cashRegisterNumber=" + cashRegisterNumber.getCashRegisterNumber() + '}';
    }
    
    
}
