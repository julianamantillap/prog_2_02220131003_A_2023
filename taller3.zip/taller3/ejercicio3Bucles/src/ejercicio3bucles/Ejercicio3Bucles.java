/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio3bucles;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio3Bucles {

   
    public static void main(String[] args) {
       Scanner scanner = new Scanner (System.in);
       String cadena;
       
       char caracter;
       int vocal = 0;
       
       System.out.println("el programa analizara si la palabra tiene vocales o no");
       System.out.print("introduce la palabra a analizar, en caso de querer terminar el programa, introduce un espacio\n");
       cadena = scanner.nextLine();
       
       while (!cadena.equals(" ")) {
           
           for (int i=0; (i < cadena.length()); i++){
               caracter = cadena.toUpperCase().charAt(i);
               if (caracter == 'A' || caracter == 'E' || caracter == 'I' || caracter == 'O' || caracter == 'U') {
                   vocal++;
               }
           }
           System.out.println("La palabra tiene: "+vocal+" vocales\n");
           vocal = 0;
           
           System.out.print("introduce nuevos caracteres a analizar, en caso de querer terminar el programa, introduce un espacio: \n");
           cadena = scanner.nextLine();       
        }
           
   }
       
}
    
