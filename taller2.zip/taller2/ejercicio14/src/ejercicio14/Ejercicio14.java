/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio14;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner;
public class Ejercicio14 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        int numero;
        int digito1;
        int digito2;
        int inverso; 
        
        System.out.println("en este programa se calcula el numero inverso a uno dado de 2 cifras");
        System.out.println("introduce el valor del numero: ");
        numero = scanner.nextInt();
        
        digito1 = numero / 10;
        digito2 = numero % 10;
        inverso = digito2 *10 + digito1;
        
        System.out.println("el numero inverso es "+inverso);
    }
    
}
