/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package udes.seriefibonnaci;
import java.util.Scanner;
/**
 *
 * @author juli.mantilla
 */
public class SerieFibonnaci {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner (System.in);
        System.out.println("¿Cuantos núemros desea calcular de la serie fibonacci?");
        int cant = sc.nextInt();
        
        int n1 = 0;
        int n2 = 1;
        
        System.out.println("Los primeros " + cant + " números de la serie Fibonacci son:");
        for (int i = 1; i <= cant; i++) {
            
            //imprimo n1 / 0
            //n1= 0 n2 = 1
            //suma= n1+n2 0+1=1
            //n1 = n2 - 1
            //n2 = sum - 1
            
            //imprimo n1 / 1
            //n1= 1 n2 = 1
            //suma= n1+n2 1+1=2
            //n1 = n2 -> 1
            //n2 = sum -> 2
            
            //imprimo n1 / 1
            //n1= 1 n2 = 2
            //suma= n1+n2 1+2=3
            //n1 = n2 -> 2
            //n2 = sum -> 3
            
            //imprimo n1 / 2
            //n1= 2 n2 = 3
            //suma= n1+n2 2+3=5
            //n1 = n2 -> 3
            //n2 = sum -> 5
            
            //imprimo n1 / 3
            //n1= 3 n2 = 5
            //suma= n1+n2 3+5=8
            //n1 = n2 -> 5
            //n2 = sum -> 8
            
            //imprimo n1 / 5
            //n1= 3 n2 = 5
            //suma= n1+n2 3+5=8
            //n1 = n2 -> 5
            //n2 = sum -> 8
            System.out.println(n1);
            int sum = n1 + n2;
            n1 = n2;
            n2 = sum;
        }  
    }
}
