/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author julianamantilla
 */
public class ciudad {
    
    int habitantes;
    int pais;
    int tamaño;
    String nombre;
    String ubicacion;

    public ciudad(int habitantes, int pais, int tamaño, String nombre, String ubicacion) {
        this.habitantes = habitantes;
        this.pais = pais;
        this.tamaño = tamaño;
        this.nombre = nombre;
        this.ubicacion = ubicacion;
    }

    public ciudad() {
    }

    public int getHabitantes() {
        return habitantes;
    }

    public int getPais() {
        return pais;
    }

    public int getTamaño() {
        return tamaño;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setHabitantes(int habitantes) {
        this.habitantes = habitantes;
    }

    public void setPais(int pais) {
        this.pais = pais;
    }

    public void setTamaño(int tamaño) {
        this.tamaño = tamaño;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }
    
    
    
    
}
