/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio13;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner;
public class Ejercicio13 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        double numero;
        double raiz2;
        double raiz3;
        
        System.out.println("en este programa se calcula la raiz cuadrada y cubica de un numero");
        System.out.println("introduce el valor del numero: ");
        numero = scanner.nextDouble();
        
        raiz2 = Math.sqrt (numero);
        
        raiz3 = Math.cbrt(numero);
        
        System.out.println("la raiz cuadrada de "+numero + " es " + raiz2);
        System.out.println("la raiz cubica de "+numero + " es "+ raiz3);
    }
    
}
