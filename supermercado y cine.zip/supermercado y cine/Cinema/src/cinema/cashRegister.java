/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cinema;

/**
 *
 * @author julianamantilla
 */

public class cashRegister {
    
    private int cashRegisterNumber;
    private Worker worker;
    private String cashRegisterType;
    private String paymentMethod;

    public cashRegister(int cashRegisterNumber, Worker employerName, String cashRegisterType, String paymentMethod) {
        this.cashRegisterNumber = cashRegisterNumber;
        this.worker = employerName;
        this.cashRegisterType = cashRegisterType;
        this.paymentMethod = paymentMethod;
    }

    public cashRegister() {
    }
    
    

    public int getCashRegisterNumber() {
        return cashRegisterNumber;
    }

    public void setCashRegisterNumber(int cashRegisterNumber) {
        this.cashRegisterNumber = cashRegisterNumber;
    }

    public Worker getWorker() {
        return worker;
    }

    public void setWorker(Worker employer) {
        this.worker = employer;
    }

    public String getCashRegisterType() {
        return cashRegisterType;
    }

    public void setCashRegisterType(String cashRegisterType) {
        this.cashRegisterType = cashRegisterType;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    @Override
    public String toString() {
        return "cashRegister{" + "cashRegisterNumber=" + cashRegisterNumber + ", worker=" + worker + ", cashRegisterType=" + cashRegisterType + ", paymentMethod=" + paymentMethod + '}';
    }
    
    
    
    
}
