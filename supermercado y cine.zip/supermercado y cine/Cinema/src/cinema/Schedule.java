/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cinema;

/**
 *
 * @author julianamantilla
 */
public class Schedule {
    
    private String childrenSchedule;
    private String familySchedule;
    private String holidays;

    public Schedule(String childrenSchedule, String familySchedule, String holidays) {
        this.childrenSchedule = childrenSchedule;
        this.familySchedule = familySchedule;
        this.holidays = holidays;
    }

    public Schedule() {
    }
    
    

    public String getChildrenSchedule() {
        return childrenSchedule;
    }

    public void setChildrenSchedule(String childrenSchedule) {
        this.childrenSchedule = childrenSchedule;
    }

    public String getFamilySchedule() {
        return familySchedule;
    }

    public void setFamilySchedule(String familySchedule) {
        this.familySchedule = familySchedule;
    }

    public String getHolidays() {
        return holidays;
    }

    public void setHolidays(String holidays) {
        this.holidays = holidays;
    }
    
    
    
}
