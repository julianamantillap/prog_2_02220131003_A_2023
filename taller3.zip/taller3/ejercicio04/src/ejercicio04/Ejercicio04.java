/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio04;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio04 {

   
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        String cadena;
        
        System.out.println("este programa pide una cadena y comprueba si es una letra mayuscula");
        System.out.print("introduce la cadena que desees: ");
        cadena = scanner.nextLine();
        
        if (cadena.length() != 1){
            System.out.println("la cadena no es una letra mayuscula");
        }else if ((cadena.compareTo("A") >= 0) && (cadena.compareTo("Z")<=0)) {
            System.out.println("la cadena es una letra mayuscula");
        }else {
            System.out.println("la cadena no es una letra mayuscula");
            
        }
    }
    
}
