/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio2bucles;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio2Bucles {

   
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner (System.in);
        
        int numero = 0;
        int contador;
        int mayor = 0;
        int igual = 0;
        int menor = 0;
        
        System.out.println("el programa pide una cantidad de numeros e indica cuantos son postivos, negativos e iguales a cero");
        System.out.println("introduce la cantidad de numeros que se van a validar: ");
        contador = scanner.nextInt();
        do {
            if (contador <= 0) {
                System.out.println("el numero introducido debe ser un entero positivo, porfavor introduzca un nuevo valor");
                contador = scanner.nextInt();
            }
        }while (contador <= 0);
        
        while (contador > 0) {
            System.out.println("introduce un numero: ");
            numero = scanner.nextInt();
            contador--;
            if (numero > 0) {
                mayor ++;
            }else if (numero < 0) {
                menor ++;
            }else {
                igual ++;
            }
        }
        System.out.print("introduciste todos los numeros:\n" + mayor + " son positivos\n" + menor + " son negativos\n" + igual + " son iguales a 0\n");
    }
    
}
