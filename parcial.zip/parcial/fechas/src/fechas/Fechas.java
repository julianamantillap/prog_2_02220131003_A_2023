/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package fechas;


import java.util.Scanner;

/**
 *
 * @author julianamantilla
 */
public class Fechas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
     
       
       int año;
       
       int mes;
       
       int dia;
       
       System.out.print("digite el año: ");
       año = scanner.nextInt();
       System.out.print("digite el mes: ");
       mes = scanner.nextInt();
       System.out.print("digite el dia: ");
       dia = scanner.nextInt();
       
       int diaF = 28;
       
       if (año % 4 == 0)
           diaF = 29;
      
       switch (mes) {
           case 1: 
               if (dia > 31) 
                   System.out.print("el dia no es valido");
               else 
                   System.out.print("han transcurrido " + dia + "dias del año");
            break;
           case 2:
               if (año % 4 == 0 && dia > 30) {
                   System.out.print ("han transcurrido "+ (dia + 31) + "dias del año" );
                   
               }
               else if (dia > 29) {
                   System.out.print("han transcurrido "+ (dia + 31) + "dias del año ");
               }
               else 
                   System.out.print("el dia no es valido");
            break;
           case 3: 
               if (dia > 31) 
                   System.out.print("el dia no es valido");
               else 
                   System.out.print("han transcurrido " + (dia + 31 + diaF) + "dias del año");
            break;
           case 4: 
               if (dia > 30)
                   System.out.print ("el dia no es valido");
               else 
                   System.out.print("han transcurrido " + (dia + 62 + diaF) + "dias del año");
            break;
           case 5:
               if (dia > 31)
                   System.out.print("el dia no es valido");
               else 
                   System.out.print("han transcurrido " + (dia + 92 + diaF) + "dias del año");
           break;
           case 6: 
               if (dia > 30)
                   System.out.print("el dia no es valido");
               else 
                   System.out.print("han transcurrido " + (dia + 123 + diaF) + "dias del año");
            break;
           case 7: 
               if (dia > 31)
                   System.out.print("el dia no es valido");
               else 
                   System.out.print("han transcurrido " + (dia + 153 + diaF) + "dias del año");
            break;
           case 8:
               if (dia > 31)
                   System.out.print("el dia no es valido");
               else
                   System.out.print("han transcurrido " + (dia + 184 + diaF) + "dias del año");
            break;
           case 9:
               if (dia > 30)
                   System.out.print("el dia no es valido");
               else 
                   System.out.print("han transcurrido " + (dia + 215 + diaF) + "dias del año");
            break;
           case 10:
               if (dia > 31)
                   System.out.print("el dia no es valido");
               else 
                   System.out.print ("han transcurrido " + (dia + 245 + diaF) + "dias del año");
            break;
           case 11:
               if (dia > 30)
                   System.out.print ("el dia no es valido");
               else 
                   System.out.print("han transcurrido " + (dia + 276 + diaF ) + "dias del año");
            break;
           case 12:
               if (dia > 31)
                   System.out.print("el dia no es valido");
               else 
                   System.out.print("han transcurrido " + (dia + 306 + diaF ) + "dias del año");
            break;
          
              
       }
               
    }
    
    
    
}
