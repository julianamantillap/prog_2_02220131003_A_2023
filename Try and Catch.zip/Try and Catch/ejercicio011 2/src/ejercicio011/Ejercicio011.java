/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio011;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio011 {



    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numeroAlumnos;

        System.out.println("En este programa se calcula el precio a pagar por alumno en el viaje de fin de curso, según la cantidad que se apunte.");
        
        try {
            System.out.print("Número de alumnos: ");
            numeroAlumnos = scanner.nextInt();

            if (numeroAlumnos >= 100) {
                System.out.println("El pago a la agencia es de " + numeroAlumnos * 65 + " euros y cada uno debe pagar 65 euros.");
            } else if (numeroAlumnos < 100 && numeroAlumnos >= 50) {
                System.out.println("El pago a la agencia es de " + numeroAlumnos * 70 + " euros y cada uno debe pagar 70 euros.");
            } else if (numeroAlumnos < 50 && numeroAlumnos >= 30) {
                System.out.println("El pago a la agencia es de " + numeroAlumnos * 95 + " euros y cada uno debe pagar 95 euros.");
            } else {
                System.out.println("El costo del autobús es de 4000 euros y cada alumno debe pagar " + (4000.0 / numeroAlumnos) + " euros.");
            }
        } catch (InputMismatchException ex) {
            System.out.println("se deben ingresar solo numeros, no letras");
        }
    }
}

