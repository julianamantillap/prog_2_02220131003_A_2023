/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio10bucles;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */


public class Ejercicio10Bucles {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("Introduce el número de niveles que tendrá la pirámide: ");
            int numeroNiveles = scanner.nextInt();

            int numeroPosiciones = numeroNiveles * 2 - 1;
            int posicionInicial = numeroNiveles;
            int posicionFinal = numeroNiveles;

            for (int i = 0; i < numeroNiveles; i++) {
                int contador = 1;
                String resultado = "";

                for (int j = 0; j <= numeroPosiciones; j++) {
                    if ((j < posicionInicial) || (j > posicionFinal)) {
                        resultado += " ";
                    } else {
                        if (j < numeroNiveles) {
                            resultado += contador;
                            contador++;
                        } else {
                            resultado += contador;
                            contador--;
                        }
                    }
                }
                System.out.println(resultado);
                posicionFinal++;
                posicionInicial--;
            }
        } catch (InputMismatchException ex) {
            System.out.println("no se pueden agregar letras, solo numeros");
        } finally {
            scanner.close();
        }
    }
}

    

