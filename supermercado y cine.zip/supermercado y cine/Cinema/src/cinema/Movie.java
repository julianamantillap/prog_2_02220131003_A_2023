/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cinema;

/**
 *
 * @author julianamantilla
 */
public class Movie {
    
    private String gender;
    private String duration;
    private Schedule schedule;
    private int ageRange;
    private String synopsis;
    private String movieType;
    private Hall hall;

    public Movie(String gender, String duration, Schedule schedule, int ageRange, String synopsis, String movieType, Hall hall) {
        this.gender = gender;
        this.duration = duration;
        this.schedule = schedule;
        this.ageRange = ageRange;
        this.synopsis = synopsis;
        this.movieType = movieType;
        this.hall = hall;
    }

    public Movie() {
    }

    public Hall getHall() {
        return hall;
    }

    public void setHall(Hall hall) {
        this.hall = hall;
    }
    
    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public Schedule getSchedule() {
        return schedule;
    }

    public void setSchedule(Schedule schedule) {
        this.schedule = schedule;
    }

    public int getAgeRange() {
        return ageRange;
    }

    public void setAgeRange(int ageRange) {
        this.ageRange = ageRange;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis;
    }

    public String getMovieType() {
        return movieType;
    }

    public void setMovieType(String movieType) {
        this.movieType = movieType;
    }

    @Override
    public String toString() {
        return "Movie{" + "gender=" + gender + ", duration=" + duration + ", schedule=" + schedule + ", ageRange=" + ageRange + ", synopsis=" + synopsis + ", movieType=" + movieType + ", hall=" + hall + '}';
    }
    
    
}
