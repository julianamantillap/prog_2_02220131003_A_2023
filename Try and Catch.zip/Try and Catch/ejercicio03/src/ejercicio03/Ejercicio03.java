/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio03;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */


public class Ejercicio03 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numerador;
        int denominador;

        System.out.println("Este programa muestra la división entre dos números enteros.");
        try {
            System.out.print("Introduce el numerador: ");
            numerador = scanner.nextInt();
            System.out.print("Introduce el denominador: ");
            denominador = scanner.nextInt();

            if (denominador != 0) {
                System.out.println((double) numerador / denominador);
            } else {
                System.out.println("El segundo número introducido es 0. Reinicie el programa e introduzca un valor válido.");
            }
        } catch (InputMismatchException ex) {
            System.out.println("no se pueden agregar letras, solo numeros");
        }
    }
}

