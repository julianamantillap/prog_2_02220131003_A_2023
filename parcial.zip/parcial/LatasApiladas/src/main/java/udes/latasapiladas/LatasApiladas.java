/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package udes.latasapiladas;
import java.util.Scanner;

/**
 *
 * @author juli.mantilla
 */


public class LatasApiladas {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introduce el número de latas que quieres apilar: ");
        int numLatas = scanner.nextInt();

        int pisoActual = 1;
        int latasApiladas = 0;
        
        //0 + 1 <= 17
        //latas= 0+=1 = 1
        //piso=2
        //1+2 = 3 <=17
        //latas = 3
        //piso3
        //3+3<=17
        //latas=3+3=6
        //piso=4
        //6+4=10 <= 17
        //latas=6+4=10
        //piso=5
        //10+5=15 <=17
        //latas=15
        //piso=6
        //15+6= 21 <=17 XXX
        
        //latasfaltantes = 17-15  = 2
        //Latascercanas = 15 + 

        while (latasApiladas + pisoActual <= numLatas) {
            latasApiladas += pisoActual;
            pisoActual++;
        }

        int latasFaltantes = numLatas - latasApiladas;

        System.out.println("El número más cercano de latas que se pueden apilar es: " + latasApiladas);
        System.out.println("Faltaron: " + latasFaltantes + " Latas por Apilar");
    }
}

