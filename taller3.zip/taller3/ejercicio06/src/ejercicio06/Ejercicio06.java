/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio06;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio06 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
    int nota;
    int edad;
    String sexo; 
       
       
System.out.println("Este programa nos calcula la aceptación de una solicitud"
        + " en base a los siguientes parámetros:");
    System.out.print("Edad: ");
    edad = scanner.nextInt();
    System.out.print("Nota: ");
    nota = scanner.nextInt(); scanner.nextLine();
    System.out.print("Sexo (M o F): ");
    sexo = scanner.nextLine();
    
if (!sexo.toUpperCase().equals("M") && !sexo.toUpperCase().equals("F")) {
      System.out.println("El valor de sexo introducido es incorrecto.\n"
          + "por favor, reenvíe el formulario.");
    } else if ((nota >= 5) && (edad >= 18) && (sexo.toUpperCase().equals("M"))) {
      System.out.println("POSIBLE");
    }else if ((nota >= 5) && (edad >= 18) && (sexo.toUpperCase().equals("F"))) {
       System.out.println("ACEPTADA");
    }else {
        System.out.println("NO ACEPTADA");
    }
    }
  }
