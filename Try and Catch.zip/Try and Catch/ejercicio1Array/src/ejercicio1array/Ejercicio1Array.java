/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio1array;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */


public class Ejercicio1Array {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] numeros = new int[10];

        System.out.println("El programa pedirá 10 números y luego serán impresos en orden inverso.");

        try {
            for (int i = 0; i < 10; i++) {
                System.out.print("Digite el número " + (i + 1) + ": ");
                numeros[i] = scanner.nextInt();
            }

            System.out.println("Valores introducidos en orden inverso:");

            for (int i = 9; i >= 0; i--) {
                System.out.println("Número " + (i + 1) + ": " + numeros[i]);
            }
        } catch (InputMismatchException ex) {
            System.out.println("no se pueden agregar letras, solo numeros");
        }
    }

}
