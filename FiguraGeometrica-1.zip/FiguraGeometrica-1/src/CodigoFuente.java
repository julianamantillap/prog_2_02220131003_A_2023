/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author YullR
 */
public class CodigoFuente {

    public static void main(String[] args) {

        FiguraGeometrica[] figuras = new FiguraGeometrica[3];
        int[] ladoscuadrado = {4, 4, 4, 4};//area 8 formula lado*lado*lado*lado area 16
        int[] ladosrectangulo = {2, 4};//area 8 formula lado*lado area 8
        int[] ladostriangulo = {2, 4, 3};//area 4 formula lado*lado*lado area 24

        figuras[0] = new Cuadrado("Cuadrado", 4, ladoscuadrado);
        figuras[1] = new Rectangulo("Rectangulo", 2, ladosrectangulo);
        figuras[2] = new Triangulo("Escaleno", 3, ladostriangulo);

        for (int i = 0; i < figuras.length; i++) {

            System.out.println(figuras[i].calcularArea());

        }

        for (int i = 0; i < figuras.length; i++) {

            System.out.println(figuras[i].calcularPerimetro());
        }

    }

}
