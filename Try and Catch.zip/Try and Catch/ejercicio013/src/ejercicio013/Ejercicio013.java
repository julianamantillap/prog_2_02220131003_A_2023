/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio013;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio013 {

        public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int dado;

        System.out.println("El programa indica el número parecido en el lado opuesto al que salió en el dado.");
        
        try {
            System.out.print("Resultado de la cara obtenida: ");
            dado = scanner.nextInt();

            switch (dado) {
                case 1:
                    System.out.println("En la cara opuesta está el \"seis\".");
                    break;
                case 2:
                    System.out.println("En la cara opuesta está el \"cinco\".");
                    break;
                case 3:
                    System.out.println("En la cara opuesta está el \"cuatro\".");
                    break;
                case 4:
                    System.out.println("En la cara opuesta está el \"tres\".");
                    break;
                case 5:
                    System.out.println("En la cara opuesta está el \"dos\".");
                    break;
                case 6:
                    System.out.println("En la cara opuesta está el \"uno\".");
                    break;
                default:
                    System.out.println("ERROR: número incorrecto.");
            }
        } catch (InputMismatchException ex) {
            System.out.println("se deben ingresar solo numeros, no letras");
        }
    }
}

    
         
     
    
    

