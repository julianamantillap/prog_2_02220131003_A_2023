/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio12;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner;
public class Ejercicio12 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        int x1;
        int x2;
        int y1;
        int y2;
        double distancia;
        
        System.out.println("en este programa se calcula la distancia entre dos puntos dados");
        System.out.println("introduce el valor X del primer punto: ");
        x1 = scanner.nextInt();
        System.out.println("introduce el valor Y del primer punto: ");
        y1 = scanner.nextInt();
        System.out.println("introduce el valor X del segundo punto");
        x2 = scanner.nextInt();
        System.out.println("introduce el valor Y del segundo punto: ");
        y2 = scanner.nextInt();
        
        distancia = Math.sqrt (Math.pow ((x2-x1),2) + Math.pow ((y2-y1),2));
        
        System.out.println("la distancia de ambos puntos es "+distancia);
    }
    
}
