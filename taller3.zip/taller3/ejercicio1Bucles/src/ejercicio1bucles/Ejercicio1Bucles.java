/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio1bucles;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio1Bucles {

    
    public static void main(String[] args) {
       Scanner scanner = new Scanner (System.in);
       
       int numeroAleatorio;
       int intento;
       int contador = 10;
       
       numeroAleatorio = (int)(Math.random()*100+1);
       
       System.out.println("intenta adivinar un numero aleatorio entre el 1 y 100, tienes 10 intentos");
       //System.out.println(numeroAleatorio);
       
       do {
           System.out.print("Intento #:"+contador+"\n");
           System.out.print("introduce el numero que creas posible: ");
           intento = scanner.nextInt();
           
           if (intento > numeroAleatorio) {
               System.out.print("El numero que buscas es menor, te quedan " + (contador-1) + " intentos+\n");
           }else if (intento < numeroAleatorio){
               System.out.println("El numero que buscas es mayor, te quedan " + (contador-1) + " intentos");
           }else{
               System.out.print("CORRECTO! " + numeroAleatorio + " era el numero que estabas buscando, necesitaste: " +(10-(contador-1))+ " intentos");
           }
           contador --;
       } while (intento != numeroAleatorio && contador > 0);
    
       if (contador == 0) {
      System.out.println("perdiste, el numero aleatorio era: " + numeroAleatorio);
    }
  }
}
        
               
           
       
          
    
    

