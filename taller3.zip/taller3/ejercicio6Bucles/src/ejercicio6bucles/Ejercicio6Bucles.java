/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio6bucles;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio6Bucles {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        double base;
        int exponente;
        double resultado;
        
        System.out.println("el programa solicitara un numero real como base y el exponente entero positivo para calcular una potencia");
        System.out.print("introduce la base de una potencia: ");
        base = scanner.nextDouble();
        do {
            System.out.print("introduce el expontente entero de la potencia: ");
            exponente = scanner.nextInt();
            if (exponente <= 0) {
                System.out.print("error, el exponente tiene que ser un entero positivo");
                
            }
        } while (exponente <= 0);
        resultado = base;
        
        for (int i=1; i<exponente;i++) {
            resultado = (resultado*base);
            
        }
        System.out.println("el resultado de la potencia es " + resultado);
    }
    
}
