/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio7;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner;
public class Ejercicio7 {

    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingresa la cantidad de minutos: ");
        int minutos = teclado.nextInt();
        
        
        int horas = minutos / 60;
        int minutosRestantes = minutos % 60;
        
        System.out.println("la cantidad de horas es: "+horas);
        System.out.println("la cantidad de minutos es: "+minutosRestantes);
    }
    
}
