/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio17;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner;
public class Ejercicio17 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
    int hh;
    int mm;
    int ss;
    int tiempo;
    int totalSegundos;
    int segundosRestantes;
    
    System.out.println("Este programa calcula la hora de llegada de un ciclista conociendo la hora de salida y el tiempo de viaje en segundos");
    System.out.print("Pediremos la hora segmentada, introduce la HORA: ");
    hh = scanner.nextInt();
    System.out.print("Introduce los MINUTOS: ");
    mm = scanner.nextInt();
    System.out.print ("Introduce los SEGUNDOS: ");
    ss = scanner.nextInt();
    System.out.print ("Duración del viaje en segundos: ");
    tiempo = scanner.nextInt();
    
    totalSegundos = hh *3600 + mm *60 + ss + tiempo;
    
    hh = totalSegundos / 3600;
    segundosRestantes = totalSegundos % 3600;
    mm = segundosRestantes / 60;
    ss = segundosRestantes % 60;
    
    System.out.println("La hora de llegada a la ciudad B será: "+ hh +":" + mm + ":"+ss);
    }
    
}
