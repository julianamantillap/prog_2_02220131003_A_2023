/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio6;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner;
public class Ejercicio6 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        double numero1;
        double numero2;
        double numero3;
        
        System.out.println("este programa calcula la media de tres numeros introducidos");
        System.out.print("indica el primer numero: ");
        numero1 = scanner.nextDouble();
        System.out.print("indica el segundo numero: ");
        numero2 = scanner.nextDouble();
        System.out.print("indica el tercer numero: ");
        numero3 = scanner.nextDouble();
        
        System.out.println("la media entre "+numero1 + ","+ numero2 + " y "+ numero3 + " es " + ((numero1 + numero2 + numero3)/3));
    }
    
}
