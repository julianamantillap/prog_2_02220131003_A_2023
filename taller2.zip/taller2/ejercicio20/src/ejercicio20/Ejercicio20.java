/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio20;

/**
 *
 * @author julianamantilla
 */
import java.util.Scanner;
public class Ejercicio20 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
    int dosEuros;
    int unEuro;
    int cincuentaCent;
    int veinteCent;
    int diezCent;
    int total;
    int euros;
    int centimos;
    
    System.out.println("Este programa calcula el dinero total que tenemos en euros y céntimos, contando las diferentes monedas.");
    System.out.print("Monedas de 2 euros: ");
    dosEuros = scanner.nextInt();
    System.out.print("Monedas de 1 euro: ");
    unEuro = scanner.nextInt();
    System.out.print ("Monedas de 50 céntimos: ");
    cincuentaCent = scanner.nextInt();
    System.out.print ("Monedas de 20 céntimos: ");
    veinteCent = scanner.nextInt();
    System.out.print ("Monedas de 10 céntimos: ");
    diezCent = scanner.nextInt();
    
    total = dosEuros * 200 + unEuro * 100 + cincuentaCent * 50 + veinteCent * 20 + diezCent * 10;
    euros = total / 100;
    centimos = total % 100;
    
    System.out.println("Se dispone de " +euros + " euros y "+centimos + " céntimos.");
    }
    
}
