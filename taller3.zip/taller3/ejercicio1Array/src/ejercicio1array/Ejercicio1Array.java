/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio1array;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio1Array {

    
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner (System.in);
        int [] numeros = new int [10];
        
        System.out.println("el programa pedira 10 numeros y despues seran impresos en orden inverso");
        
        for (int i = 0; i < 10; i++) {
            
            System.out.print("Digite el número "+(i+1)+":");
            numeros[i] = scanner.nextInt();
            
        }
        
        System.out.println("valores introducidos en orden inverso");
        
        for (int i=9; i>=0; i--) {
            
            System.out.println("numero " +(i+1)+": " + numeros [i]);
        }
    }
    
}
