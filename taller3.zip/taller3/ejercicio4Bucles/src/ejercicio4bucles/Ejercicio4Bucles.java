/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio4bucles;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio4Bucles {

   
    public static void main(String[] args) {
       Scanner scanner = new Scanner (System.in);
       int numero1;
       int numero2;
       int minimo;
       int maximo;
       
       System.out.println("el programa imprimira todos los numeros pares entre dos numeros indicados");
       
       System.out.println("introduzca el primer numero: ");
       numero1 = scanner.nextInt();
       System.out.println("introduzca el segundo numero: ");
       numero2 = scanner.nextInt();
       
       if (numero1 < numero2) {
           minimo = numero1;
           maximo = numero2;
       }else{
           minimo = numero2;
           maximo = numero1;
       }
       
       for (int i=minimo+1; i < maximo; i++) {//6 //10
           if (i%2==0) {                      //6%2 == 0
               System.out.println(i);       //7
           }
       }
    }
    
}
