/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio05;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */


public class Ejercicio05 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int base;
        int exponente;

        System.out.println("Calculamos la potencia de un número.");
        try {
            System.out.print("Introduce la base de la potencia: ");
            base = scanner.nextInt();
            System.out.print("Introduce el exponente de la potencia: ");
            exponente = scanner.nextInt();

            if (base >= 1) {
                System.out.println("El resultado es " + (Math.pow(base, exponente)));
            } else if (exponente == 0) {
                System.out.println("El resultado es 1.");
            } else {
                System.out.println("El resultado es " + (Math.pow(base, 1 / (double) exponente)));
            }
        } catch (InputMismatchException ex) {
            System.out.println("no se pueden agregar letras, solo numeros");
        }
    }
}
