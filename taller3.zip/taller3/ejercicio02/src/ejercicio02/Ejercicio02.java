/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio02;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio02 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        int numero;
        
        System.out.println("este programa calcula si un numero es par o impar");
        System.out.print("introduce el numero: ");
        numero = scanner.nextInt();
        
        if (numero % 2 == 0){
            System.out.println("el numero, "+numero + " es par ");
        }else {
            System.out.println("el numero "+numero + " es impar ");
            
        }
    }
    
}
