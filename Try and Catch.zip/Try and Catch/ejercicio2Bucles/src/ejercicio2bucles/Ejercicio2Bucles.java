/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio2bucles;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */


public class Ejercicio2Bucles {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numero = 0;
        int contador;
        int mayor = 0;
        int igual = 0;
        int menor = 0;

        System.out.println("El programa pide una cantidad de números e indica cuántos son positivos, negativos e iguales a cero.");
        System.out.println("Introduce la cantidad de números que se van a validar: ");

        try {
            contador = scanner.nextInt();

            while (contador <= 0) {
                System.out.println("El número introducido debe ser un entero positivo. Por favor, introduce un nuevo valor: ");
                contador = scanner.nextInt();
            }

            while (contador > 0) {
                System.out.println("Introduce un número: ");
                numero = scanner.nextInt();
                contador--;
                if (numero > 0) {
                    mayor++;
                } else if (numero < 0) {
                    menor++;
                } else {
                    igual++;
                }
            }
            System.out.println("Introdujiste todos los números:\n" + mayor + " son positivos\n" + menor + " son negativos\n" + igual + " son iguales a 0");
        } catch (InputMismatchException ex) {
            System.out.println("no se pueden agregar letras, solo numeros");
        }
    }

}

