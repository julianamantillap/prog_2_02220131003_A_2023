/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author julianamantilla
 */
public class Infraestructure {   
    
    private String adress;
    private int hallwayNumber;
    private String hallwayType;
    private String parking;
    private double areaSize;

    public Infraestructure(String adress, int hallwayNumber, String hallwayType, String parking, double areaSize) {
        this.adress = adress;
        this.hallwayNumber = hallwayNumber;
        this.hallwayType = hallwayType;
        this.parking = parking;
        this.areaSize = areaSize;
    }

    public Infraestructure() {
    }
    
    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public int getHallwayNumber() {
        return hallwayNumber;
    }

    public void setHallwayNumber(int hallwayNumber) {
        this.hallwayNumber = hallwayNumber;
    }

    public String getHallwayType() {
        return hallwayType;
    }

    public void setHallwayType(String hallwayType) {
        this.hallwayType = hallwayType;
    }

    public String getParking() {
        return parking;
    }

    public void setParking(String parking) {
        this.parking = parking;
    }

    public double getAreaSize() {
        return areaSize;
    }

    public void setAreaSize(double areaSize) {
        this.areaSize = areaSize;
    }

    @Override
    public String toString() {
        return "Infraestructure{" + "adress=" + adress + ", hallwayNumber=" + hallwayNumber + ", hallwayType=" + hallwayType + ", parking=" + parking + ", areaSize=" + areaSize + '}';
    }
    
    
    
}
