/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio016;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio016 {

   
    public static void main(String[] args) {
       Scanner scanner = new Scanner (System.in);
       int peso;
       int zona;
       
       System.out.println("calcula la tarifa para el envio segun peso y zona de destino");
       System.out.println("zonas de envio: ");
       System.out.println("1. - America del Norte");
       System.out.println("2. - America central");
       System.out.println("3. - America del Sur");
       System.out.println("4. - Europa");
       System.out.println("5. - Asia");
       zona = scanner.nextInt();
       System.out.print("introduce el peso del paquete en gramos: ");
       peso = scanner.nextInt();
       
       if (peso > 5) {
           System.out.println("el paquete no puede ser admitido por motivos de seguridad");
       }else if (peso < 1) {
           System.out.println("el peso del paquete debe ser un entero positivo");
       } else {
    switch (zona) {
        case 1:
            System.out.println("el paquete de " + peso + " kilogramos enviado a America del Norte sale por " + (peso*24) + "euros");
            break;
        case 2:
            System.out.println("el paquete de " + peso + " kilogramos enviado a America Central sale por " + (peso*24) + "euros");
            break;
        case 3:
            System.out.println("el paquete de " + peso + " kilogramos enviado a America del sur sale por " + (peso*24) + "euros");
            break;
        case 4:
            System.out.println("el paquete de " + peso + "kilogramos enviado a Europa sale por " + (peso*24) + "euros");
            break;
        case 5:
            System.out.println("el paquete de " + peso + "kilogramos enviado a Asia sale por " + (peso*24) + "euros");
            break;
        default:
            System.out.println("ERROR: zona elegida incorrecta");
            break;
            
       }
    }
    
    }
}

