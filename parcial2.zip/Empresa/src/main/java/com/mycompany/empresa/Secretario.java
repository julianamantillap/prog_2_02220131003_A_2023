/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.empresa;

/**
 *
 * @author Juliana
 */
public class Secretario extends Empleado{
    
    private String despacho;
    private String fax;

    public Secretario() {
    }

    public Secretario(String despacho, String fax, String nombre, String apellidos, String direccion, String dni, String numcontacto, double salario) {
        super(nombre, apellidos, direccion, dni, numcontacto, salario);
        this.despacho = despacho;
        this.fax = fax;
    }

    public String getDespacho() {
        return despacho;
    }

    public void setDespacho(String despacho) {
        this.despacho = despacho;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    @Override
    public String toString() {
        return "Secretario{" + super.toString() + "despacho=" + despacho + ", fax=" + fax + '}';
    }
    
    public void aumentarSalario(){
        double incremento = super.getSalario()*0.05;
        super.aumentarSalario(incremento);
    } 
    
    
    
}
