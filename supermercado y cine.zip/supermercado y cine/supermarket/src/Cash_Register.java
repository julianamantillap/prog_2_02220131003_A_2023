/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author julianamantilla
 */
public class Cash_Register {
    
    private String cashRegisterNumber;
    private Worker employerName;
    private String cashRegisterType;
    private String paymentMethod;

    public Cash_Register(String cashRegisterNumber, Worker employerName, String cashRegisterType, String paymentMethod) {
        this.cashRegisterNumber = cashRegisterNumber;
        this.employerName = employerName;
        this.cashRegisterType = cashRegisterType;
        this.paymentMethod = paymentMethod;
    }

    public Cash_Register() {
    }
    
    public String getCashRegisterNumber() {
        return cashRegisterNumber;
    }

    public void setCashRegisterNumber(String cashRegisterNumber) {
        this.cashRegisterNumber = cashRegisterNumber;
    }

    public Worker getEmployerName() {
        return employerName;
    }

    public void setEmployerName(Worker employerName) {
        this.employerName = employerName;
    }

    public String getCashRegisterType() {
        return cashRegisterType;
    }

    public void setCashRegisterType(String cashRegisterType) {
        this.cashRegisterType = cashRegisterType;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    @Override
    public String toString() {
        return "Cash_Register{" + "cashRegisterNumber=" + cashRegisterNumber + ", employerName=" + employerName + ", cashRegisterType=" + cashRegisterType + ", paymentMethod=" + paymentMethod + '}';
    }
    
    
    
}