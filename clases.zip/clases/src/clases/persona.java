/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author julianamantilla
 */
public class persona {
    
    double altura;
    int edad;
    double peso;
    String colorPiel;
    String colorPelo;

    public persona(double altura, int edad, double peso, String colorPiel, String colorPelo) {
        this.altura = altura;
        this.edad = edad;
        this.peso = peso;
        this.colorPiel = colorPiel;
        this.colorPelo = colorPelo;
    }

    public persona() {
    }

    public double getAltura() {
        return altura;
    }

    public int getEdad() {
        return edad;
    }

    public double getPeso() {
        return peso;
    }

    public String getColorPiel() {
        return colorPiel;
    }

    public String getColorPelo() {
        return colorPelo;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public void setColorPiel(String colorPiel) {
        this.colorPiel = colorPiel;
    }

    public void setColorPelo(String colorPelo) {
        this.colorPelo = colorPelo;
    }

   
    
    
}
