/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cinema;

/**
 *
 * @author julianamantilla
 */
public class Food {
    
    private String foodType;
    private String drinkType;
    private double price;    

    public Food(String foodType, String drinkType, double price) {
        this.foodType = foodType;
        this.drinkType = drinkType;
        this.price = price;
    }

    public Food() {
    }
    
    

    public String getFoodType() {
        return foodType;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
    }

    public String getDrinkType() {
        return drinkType;
    }

    public void setDrinkType(String drinkType) {
        this.drinkType = drinkType;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Food{" + "foodType=" + foodType + ", drinkType=" + drinkType + ", price=" + price + '}';
    }

    
    
    
    
}
