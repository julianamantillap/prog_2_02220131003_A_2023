/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package udes.estadisticaasignaturashoras;
import java.util.Scanner;

public class EstadisticaAsignaturasHoras {

    public static void main(String[] args) {

        // Crear un arreglo bidimensional para almacenar las horas de estudio mensuales
        int[][] horasDeEstudio = new int[5][12];
        Scanner sc = new Scanner(System.in);
        String[] nombresAsignaturas = new String[5];
        
        System.out.println();
        
        for(int i=0;i<nombresAsignaturas.length; i++){
            System.out.println("Ingrese las Asignaturas que desea guardar registros");
            nombresAsignaturas[i]=sc.nextLine();
        }

        // Pedir al usuario que ingrese las horas de estudio mensuales de cada asignatura
        for (int i = 0; i < 5; i++) {
            System.out.println("Ingrese las horas de estudio mensuales para " + nombresAsignaturas[i]);
            for (int j = 0; j < 12; j++) {
                System.out.print("Mes " + (j+1) + ": ");
                horasDeEstudio[i][j] = sc.nextInt();
            }
        }

        // Calcular el total de horas anuales dedicadas a cada asignatura
        int[] totalHorasAsignaturas = new int[5];
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 12; j++) {
                totalHorasAsignaturas[i] += horasDeEstudio[i][j];
            }
            System.out.println("Total de horas anuales dedicadas a " + nombresAsignaturas[i] + ": " + totalHorasAsignaturas[i]);
        }
        
        System.out.println();
        
        // Calcular el total mensual de horas dedicadas a estudiar
        int[] totalHorasMensuales = new int[12];
        for (int i = 0; i < 12; i++) {
            for (int j = 0; j < 5; j++) {
                totalHorasMensuales[i] += horasDeEstudio[j][i];
            }
            System.out.println("Total de horas mensuales dedicadas a estudiar en el mes " + (i+1) + ": " + totalHorasMensuales[i]);
        }
        
        System.out.println();
        
        // Encontrar la asignatura más estudiada
        int maxHoras = 0;
        int maxHorasIndex = 0;
        for (int i = 0; i < 5; i++) {
            if (totalHorasAsignaturas[i] > maxHoras) {
                maxHoras = totalHorasAsignaturas[i];
                maxHorasIndex = i;
            }
        }
        System.out.println("La asignatura más estudiada es " + nombresAsignaturas[maxHorasIndex] + " con " + maxHoras + " horas anuales.");
        
        System.out.println();

        // Encontrar la asignatura menos estudiada
        int minHoras = totalHorasAsignaturas[0];
        int minHorasIndex = 0;
        for (int i = 1; i < 5; i++) {
            if (totalHorasAsignaturas[i] < minHoras) {
                minHoras = totalHorasAsignaturas[i];
                minHorasIndex = i;
            }
        }
        System.out.println("La asignatura menos estudiada es " + nombresAsignaturas[minHorasIndex] + " con " + minHoras + " horas anuales.");

    }        
}

