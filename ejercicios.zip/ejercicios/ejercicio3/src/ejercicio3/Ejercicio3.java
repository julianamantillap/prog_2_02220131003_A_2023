/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio3;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */

public class Ejercicio3 {

   
    
    public static void main(String[] args) {
       Scanner entrada = new Scanner (System.in);
        
        double cateto1, cateto2, hipotenusa;
        
        System.out.println("digite el primer cateto");
        cateto1 = entrada.nextDouble();
        
        System.out.println("digite el segundo cateto");
        cateto2 = entrada.nextDouble();
        
        
        
        
        hipotenusa = Math.sqrt(Math.pow(cateto1, 2) + Math.pow(cateto2, 2));
        System.out.println("el valor de la hipotenusa es: "+hipotenusa);
    }
    
    
}
