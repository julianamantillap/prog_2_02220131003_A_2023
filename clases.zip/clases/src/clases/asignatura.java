/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author julianamantilla
 */
public class asignatura {
    
    String rama;
    String facultad;
    String profesor;
    int estudiantes;

    public asignatura(String rama, String facultad, String profesor, int estudiantes) {
        this.rama = rama;
        this.facultad = facultad;
        this.profesor = profesor;
        this.estudiantes = estudiantes;
    }

    public asignatura() {
    }

    public String getRama() {
        return rama;
    }

    public String getFacultad() {
        return facultad;
    }

    public String getProfesor() {
        return profesor;
    }

    public int getEstudiantes() {
        return estudiantes;
    }

    public void setRama(String rama) {
        this.rama = rama;
    }

    public void setFacultad(String facultad) {
        this.facultad = facultad;
    }

    public void setProfesor(String profesor) {
        this.profesor = profesor;
    }

    public void setEstudiantes(int estudiantes) {
        this.estudiantes = estudiantes;
    }
    
    
    
}
