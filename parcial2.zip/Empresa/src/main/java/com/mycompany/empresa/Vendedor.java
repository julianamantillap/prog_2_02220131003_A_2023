/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.empresa;

/**
 *
 * @author Juliana
 */
public class Vendedor extends Empleado{
    
    private Coche c1;
    private String telefono;
    private String areaventa;
    private double comision;
    private Cliente[] listaclientes;

    public Vendedor(Coche c1, String telefono, String areaventa, double comision, String nombre, String apellidos, String direccion, String dni, String numcontacto, double salario) {
        super(nombre, apellidos, direccion, dni, numcontacto, salario);
        this.c1 = c1;
        this.telefono = telefono;
        this.areaventa = areaventa;
        this.comision = comision;
    }

    public Coche getC1() {
        return c1;
    }

    public void setC1(Coche c1) {
        this.c1 = c1;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getAreaventa() {
        return areaventa;
    }

    public void setAreaventa(String areaventa) {
        this.areaventa = areaventa;
    }

    public double getComision() {
        return comision;
    }

    public void setComision(double comision) {
        this.comision = comision;
    }

    public Cliente[] getListaclientes() {
        return listaclientes;
    }

    public void setListaclientes(Cliente[] listaclientes) {
        this.listaclientes = listaclientes;
    }
    
    public void darAltaCliente(){
        
    }
    
    public void darBajaCliente(){
        
    }
    
    @Override
    public String toString() {
        return "Vendedor{" + super.toString() + "coche=" + c1.getMarca() + " " + c1.getMatricula() + ", telefono=" + telefono + ", area de venta=" + areaventa + ", comision=" + comision + '}';
    }
    
    public void aumentarSalario(){
        double incremento = super.getSalario()*0.10;
        super.aumentarSalario(incremento);
    }
    
}
