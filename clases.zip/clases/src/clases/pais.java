/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author julianamantilla
 */
public class pais {
    
    String nombre;
    int habitantes;
    String ubicacion;
    int tamaño;

    public pais(String nombre, int habitantes, String ubicacion, int tamaño) {
        this.nombre = nombre;
        this.habitantes = habitantes;
        this.ubicacion = ubicacion;
        this.tamaño = tamaño;
    }

    public pais() {
    }

    public String getNombre() {
        return nombre;
    }

    public int getHabitantes() {
        return habitantes;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public int getTamaño() {
        return tamaño;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setHabitantes(int habitantes) {
        this.habitantes = habitantes;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public void setTamaño(int tamaño) {
        this.tamaño = tamaño;
    }
    
    
}
