/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio05;
import java.util.Scanner;
/**
 *
 * @author julianamantilla
 */
public class Ejercicio05 {

    
    public static void main(String[] args) {
       Scanner scanner = new Scanner (System.in);
       int base;
       int exponente;
       
       System.out.println("calculamos la potencia de un numero: ");
       System.out.print("introduce la base de la pontencia: ");
       base = scanner.nextInt();
       System.out.print("introduce el exponente de la potencia: ");
       exponente = scanner.nextInt();
       
       if (base >= 1) {
           System.out.println("el resultado es " + (Math.pow(base, exponente)));
       }else if (exponente == 0) {
           System.out.println("el resulado es 1 ");
       }else {
    System.out.println("el resultado es " + (Math.pow(base, 1/exponente)));
       }
    }
    
}
