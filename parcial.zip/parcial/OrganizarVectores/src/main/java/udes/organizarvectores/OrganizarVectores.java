/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package udes.organizarvectores;
import java.util.Scanner;

/**
 *
 * @author juli.mantilla
 */
public class OrganizarVectores {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Digite el tamaño de los vectores");
        int t = sc.nextInt();
        
        int[] v1 = new int[t];
        int[] v2 = new int[t];
        
        for(int i=0;i<v1.length;i++){
            System.out.println("Digite los números del vector 1");
            v1[i] = sc.nextInt();
        }

        for(int i=0;i<v2.length;i++){
            System.out.println("Digite los números del vector 2");
            v2[i] = sc.nextInt();
        }
        
        int[] v3 = new int[v1.length+v2.length];
                
         // Fusionar los vectores
        for (int i = 0; i < v1.length; i++) 
            v3[i] = v1[i];
        

        // Copiar elementos del segundo vector al vector fusionado
        for (int i = 0; i < v2.length; i++)
            v3[v1.length + i] = v2[i];
        
        // Vector Fusionado
        System.out.println("Vectore fusionados en un solo vector: ");
        for (int i = 0; i < v3.length; i++)
            System.out.print(v3[i]+" - ");
        
        System.out.println();

        // Ordenamiento ascendente
        for (int i = 0; i < v3.length - 1; i++) {
            for (int j = 0; j < v3.length - i - 1; j++) {
                if (v3[j] > v3[j + 1]) {
                    int temp = v3[j];
                    v3[j] = v3[j + 1];
                    v3[j + 1] = temp;
                }
            }
        }
        
        System.out.println("Vector ordenado de manera ascendente:");
        for (int i = 0; i < v3.length; i++) {
            System.out.print(v3[i] + " ");
        }
        System.out.println();
        
        // Ordenamiento descendente
        for (int i = 0; i < v3.length - 1; i++) {
            for (int j = 0; j < v3.length - i - 1; j++) {
                if (v3[j] < v3[j + 1]) {
                    int temp = v3[j];
                    v3[j] = v3[j + 1];
                    v3[j + 1] = temp;
                }
            }
        }
        
        System.out.println("Vector ordenado de manera descendente:");
        for (int i = 0; i < v3.length; i++) {
            System.out.print(v3[i] + " ");
        }  
    }
}
